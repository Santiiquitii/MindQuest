// index.js — Backend Sísifo (CommonJS)
const express = require('express');
const cors = require('cors');

const app = express();

// ✅ CORS (para web, capacitor, etc.)
app.use(cors({ origin: '*', methods: ['GET', 'POST'] }));
app.use(express.json());

// Salud
app.get('/health', (_, res) => res.json({ ok: true, uptime: process.uptime() }));

// Chat con Sísifo (con sugerencias por emoción)
app.post('/chat', (req, res) => {
  const { mensaje } = req.body || {};

  // rutas reales de tu app
  const R = {
    explorar: '/game',
    diario: '/diario',
    actividades: '/activities',
    minijuegos: '/minijuegos',
    progreso: '/progreso',
    ia: '/ia',
    ayuda: '/ayuda',
    perfil: '/perfil',
  };

  if (!mensaje || typeof mensaje !== 'string') {
    return res.json({
      respuesta: 'Soy Sísifo 🌿. ¿Podrías contarme un poco más?',
      suggestions: [{ label: 'Abrir Ayuda', route: R.ayuda, icon: '🆘' }],
    });
  }

  const t = mensaje.toLowerCase();
  const is = {
    alegria: /(alegr(i|í)a|feliz|alegre|content[ao]|bien|agradecid[ao]|motivad[ao])/,
    tristeza: /(triste(za)?|llorar|deprimid[ao]|desanimad[ao]|nostal(g|ó)ia|me siento mal)/,
    enojo: /(enojo|enojad[ao]|molest[oa]|rabia|ira|furia)/,
    miedo: /(miedo|temor|asustad[oa]|preocupad[oa]|nervios)/,
    ansiedad: /(ansiedad|ansios[oa]|ataque de p(á|a)nico|p(á|a)nico|estr(é|e)s)/,
  };

  // alerta
  if (/(suicid|autolesi|hacerme daño|quitarme la vida)/.test(t)) {
    return res.json({
      respuesta:
        'Gracias por confiar en mí. No estás sola. Te sugiero abrir Ayuda ahora mismo para ver recursos de apoyo y líneas de atención. 💛',
      suggestions: [{ label: 'Abrir Ayuda', route: R.ayuda, icon: '🆘' }],
    });
  }

  let respuesta = 'Te escucho 🌿, cuéntame más.';
  const suggestions = [];

  if (is.alegria.test(t)) {
    respuesta = '¡Qué bueno leerte con alegría! 😊 Guardemos este momento como ancla positiva.';
    suggestions.push(
      { label: 'Registrar en Diario', route: R.diario, icon: '📘' },
      { label: 'Ver Progreso', route: R.progreso, icon: '📈' },
      { label: 'Explorar recuerdos', route: R.explorar, icon: '🧠' }
    );
  } else if (is.tristeza.test(t)) {
    respuesta = 'Siento que te sientas así 😔. Podemos escribir 5 min o leer una actividad suave.';
    suggestions.push(
      { label: 'Abrir Diario', route: R.diario, icon: '📘' },
      { label: 'Actividades de Tristeza', route: R.actividades, icon: '🌿' },
      { label: 'Mini-juegos', route: R.minijuegos, icon: '🎮' }
    );
  } else if (is.enojo.test(t)) {
    respuesta = 'La rabia marca límites 🔥. Probemos una respiración 4-4 y luego una actividad.';
    suggestions.push(
      { label: 'Actividades de Enojo', route: R.actividades, icon: '🧩' },
      { label: 'Registrar en Diario', route: R.diario, icon: '📘' },
      { label: 'Mini-juegos calmantes', route: R.minijuegos, icon: '🎮' }
    );
  } else if (is.miedo.test(t)) {
    respuesta = 'El miedo es válido 💛. Puedo guiarte con 5-4-3-2-1 o revisar IA Emocional.';
    suggestions.push(
      { label: 'IA Emocional', route: R.ia, icon: '🤖' },
      { label: 'Actividades de Miedo', route: R.actividades, icon: '🧭' },
      { label: 'Escribir en Diario', route: R.diario, icon: '📘' }
    );
  } else if (is.ansiedad.test(t)) {
    respuesta = 'La ansiedad se calma con 4-7-8 o un mini-juego breve. Estoy contigo 🕊️.';
    suggestions.push(
      { label: 'Mini-juegos de calma', route: R.minijuegos, icon: '🌬️' },
      { label: 'Actividades de Ansiedad', route: R.actividades, icon: '🪷' },
      { label: 'Registrar en Diario', route: R.diario, icon: '📘' }
    );
  } else {
    respuesta = 'Puedo ayudarte con actividades por emoción. ¿Prefieres Actividades o tu Diario?';
    suggestions.push(
      { label: 'Ir a Actividades', route: R.actividades, icon: '🌿' },
      { label: 'Abrir Diario', route: R.diario, icon: '📘' },
      { label: 'Ver Progreso', route: R.progreso, icon: '📈' }
    );
  }

  res.json({ respuesta, suggestions });
});

// Inicio
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🤖 Sísifo escuchando en http://localhost:${PORT}`));