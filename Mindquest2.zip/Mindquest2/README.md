# MindQuest

Aplicación web React para salud mental. Incluye componentes de IA (detector facial, modelos locales) y un chatbot separado (`mindquest-bot`).

## Características
- Interfaz React para web
- Detección de emociones con modelos locales (`public/models`)
- Chatbot externo (servicio Node.js en `mindquest-bot` o remoto)

## Requisitos
- Node.js >= 16
- npm o yarn

## Instalación y desarrollo
1. Instala dependencias:

```bash
npm install
```

2. Ejecuta en modo desarrollo:

```bash
npm start
```

La app se abrirá en http://localhost:3000

## Build para producción

1. Genera los assets web:

```bash
npm run build
```

Los archivos optimizados se generarán en la carpeta `build/` y estarán listos para desplegar en cualquier servidor web.

## Modelos de IA
- Coloca los modelos (por ejemplo `face_expression_model-weights_manifest.json` y pesos) en `public/models` para que queden en `build/models` al hacer `npm run build`.
- En el código, carga modelos usando rutas relativas desde la raíz, p. ej. `/models/model.json`.

Si ves errores 404 al cargar modelos, verifica que `build/models` existe y que las rutas apuntan a `/models`.

## Chatbot (`mindquest-bot`)
- `mindquest-bot` es un servicio separado en la carpeta `mindquest-bot/`.
- Para producción, despliega el bot en un hosting (Heroku, Railway, Render, Vercel, etc.) y actualiza la URL en `src/utils/chatApi.js`.
- Para pruebas locales contra la app en el dispositivo puedes exponer tu servidor local con `ngrok` o alojarlo en la misma red y usar la IP del equipo.

## Depuración
- Usa las herramientas de desarrollo del navegador (F12) para inspeccionar la app y ver errores.
- Para la consola web, abre las DevTools y revisa la pestaña Console.

## Deploy a servidor web
- Sube la carpeta `build/` a cualquier hosting web (Netlify, Vercel, GitHub Pages, etc.).
- Para hosting estático, simplemente copia los archivos de `build/` al servidor.

## Problemas comunes
- Modelos 404: revisar `public/models` y rutas.
- Cámara: revisar permisos en Manifest y permisos en tiempo de ejecución.
- CORS / API: si el bot está remoto, habilita CORS o usa un proxy seguro.

## Contacto
Si quieres, puedo:
- Ejecutar `npm run build` aquí, o
- Crear scripts adicionales, o
- Ayudarte a desplegar `mindquest-bot` a un servicio.

---
© Proyecto MindQuest
