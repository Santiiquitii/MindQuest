// src/components/MiniGamesView.jsx
import { useState } from 'react';


/** ================== Lista de minijuegos ================== **/
const games = [
  {
    id: 'rompecabezas',
    title: 'Rompecabezas',
    type: 'iframe',
    url: 'https://jigsawgalaxy.com/',
    tags: ['atención','relajación'],
    desc: 'Relájate y diviértete armando rompecabezas con diferentes niveles. ¡Vamos, tú puedes!'
  },
  {
    id: 'memoria',
    title: 'Memoria',
    type: 'iframe',
    url: 'https://www.juegosdememoriagratis.com/',
    tags: ['memoria','concentración'],
    desc: 'Haz coincidir cartas y ejercita tu memoria.'
  },
  {
    id: 'colorear',
    title: 'Colorear',
    type: 'iframe',
    url: 'https://www.thecolor.com/',
    tags: ['creatividad','relajación'],
    desc: 'Colorea dibujos y explota ese artista que traes dentro.'
  },
];

const btnStyle = {
  padding: '8px 12px',
  border: '1px solid #ddd',
  borderRadius: 10,
  cursor: 'pointer',
  background: '#fff'
};

export default function MiniGamesView() {
  const [current, setCurrent] = useState(null);

  const renderCurrent = () => {
    if (!current) {
      return <p style={{color:'#6b7280'}}>Elige un minijuego de la lista para empezar.</p>;
    }
    if (current.type === 'internal') {
      const Cmp = current.component;
      return <Cmp />;
    }
    if (current.type === 'iframe') {
      return (
        <div>
          <h3 style={{marginTop:0}}>{current.title}</h3>
          {current.desc && <p style={{marginTop:-6, color:'#6b7280'}}>{current.desc}</p>}
          <iframe
            title={current.title}
            src={current.url}
            style={{width:'100%', height: '72vh', border:'1px solid #eee', borderRadius: 12}}
            allow="fullscreen; gamepad; accelerometer; autoplay; clipboard-write; encrypted-media"
            sandbox="allow-scripts allow-same-origin allow-forms allow-pointer-lock"
          />
          {/* Enlace opcional por si el sitio bloquea iframe */}
          <div style={{marginTop:8}}>
            <a href={current.url} target="_blank" rel="noreferrer" style={{fontSize:12, color:'#6b7280'}}>
              Si no se carga dentro, ábrelo en una pestaña nueva.
            </a>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div style={{display:'grid', gridTemplateColumns:'280px minmax(0,1fr)', gap:16}}>
      {/* Sidebar de juegos */}
      <aside className="panel glass" style={{padding:12}}>
        <h3 style={{marginBottom:8}}>Minijuegos</h3>
        <div style={{display:'grid', gap:8}}>
          {games.map(g => (
            <button
              key={g.id}
              style={{
                ...btnStyle,
                textAlign:'left',
                background: (current?.id === g.id) ? '#eef2ff' : '#fff',
                borderColor: (current?.id === g.id) ? '#c7d2fe' : '#ddd'
              }}
              onClick={() => setCurrent(g)}
            >
              <div style={{fontWeight:600}}>{g.title}</div>
              {g.desc && <div style={{fontSize:12, color:'#6b7280', marginTop:2}}>{g.desc}</div>}
              {g.tags?.length ? (
                <div style={{fontSize:11, color:'#94a3b8', marginTop:4}}>{g.tags.join(' · ')}</div>
              ) : null}
            </button>
          ))}
        </div>
      </aside>

      {/* Área del juego */}
      <section className="panel glass" style={{padding:16, minHeight: 600}}>
        {renderCurrent()}
      </section>
    </div>
  );
}
