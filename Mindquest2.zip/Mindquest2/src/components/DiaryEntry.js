import React from 'react';

const DiaryEntry = ({ entry }) => {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md mb-4 border-l-4 border-black">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold text-gray-800">{entry.emotion.name}</h3>
        <span className="text-sm text-gray-500">{new Date(entry.timestamp).toLocaleDateString()}</span>
      </div>
      <p className="text-gray-700 mb-3">{entry.text}</p>
      {entry.activity && (
        <div className="text-sm text-gray-600">
          <span className="font-semibold">Actividad realizada:</span> {entry.activity}
        </div>
      )}
    </div>
  );
};

export default DiaryEntry;