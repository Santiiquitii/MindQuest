import React, { useState } from 'react';

const HuggingFaceChat = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: 'user', text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium', {
        method: 'POST',
        headers: {
          Authorization: 'Bearer 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',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ inputs: { text: input } }),
      });

      const data = await response.json();
      const botReply = data.generated_text || 'Lo siento, no pude generar una respuesta.';

      setMessages((prev) => [...prev, { sender: 'bot', text: botReply }]);
    } catch (err) {
      console.error('Error al llamar a Hugging Face:', err);
      setMessages((prev) => [...prev, { sender: 'bot', text: 'Error al conectar con el asistente.' }]);
    }

    setLoading(false);
  };

  return (
    <div className="p-4 border rounded max-w-md mx-auto bg-white shadow">
      <h2 className="text-xl font-bold mb-2">Asistente emocional</h2>
      <div className="h-64 overflow-y-auto mb-2 border p-2 rounded bg-gray-100">
        {messages.map((msg, idx) => (
          <div key={idx} className={`mb-1 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block px-3 py-1 rounded ${msg.sender === 'user' ? 'bg-blue-200' : 'bg-green-200'}`}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="flex">
        <input
          className="flex-1 border p-2 rounded-l"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Escribe tu mensaje..."
        />
        <button onClick={sendMessage} disabled={loading} className="bg-blue-500 text-white px-4 rounded-r">
          {loading ? '...' : 'Enviar'}
        </button>
      </div>
    </div>
  );
};

export default HuggingFaceChat;
