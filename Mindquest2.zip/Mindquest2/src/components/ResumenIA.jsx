import React from "react";
import { getIADetections } from "../utils/iastorage";
import { Pie } from "react-chartjs-2";
import { motion } from "framer-motion";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function ResumenIA({ goBack }) {
  const labelCounts = getIADetections();
  const total = Object.values(labelCounts).reduce((a, b) => a + b, 0);

  const porcentajes = Object.fromEntries(
    Object.entries(labelCounts).map(([k, v]) => [k, ((v / (total || 1)) * 100).toFixed(1)])
  );

  const pieData = {
    labels: Object.keys(porcentajes),
    datasets: [
      {
        label: "% de emociones detectadas",
        data: Object.values(porcentajes),
        backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#FF9F40"],
        borderColor: "#fff",
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="panel glass">
      <motion.h2 initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="title">
        Resumen de emociones detectadas
      </motion.h2>

      {total === 0 ? (
        <p className="muted">No se han detectado emociones aún.</p>
      ) : (
        <div className="chart-wrap">
          <Pie data={pieData} />
        </div>
      )}

      <div className="actions">
        <motion.button whileTap={{ scale: 0.96 }} className="btn" onClick={goBack}>
          Volver al reconocimiento IA
        </motion.button>
      </div>
    </div>
  );
}