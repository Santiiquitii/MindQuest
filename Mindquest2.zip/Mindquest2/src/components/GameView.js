import React, { useState, useEffect } from 'react';
import EmotionCard from './EmotionCard';
import EmotionLegend from './EmotionLegend';
import { emotionsData } from '../mock/emotions';
import { getStorage, setStorage } from '../utils/storage';

const GameView = () => {
  const [availableEmotions, setAvailableEmotions] = useState([]);
  const [collectedEmotions, setCollectedEmotions] = useState(() => getStorage('collectedEmotions') || []);
  const [selectedEmotion, setSelectedEmotion] = useState(null);

  useEffect(() => {
    const spawnEmotions = () => {
      const shuffledEmotions = [...emotionsData].sort(() => 0.5 - Math.random());
      const emotionsToSpawn = shuffledEmotions.slice(0, Math.floor(Math.random() * emotionsData.length) + 1);
      setAvailableEmotions(emotionsToSpawn);
    };

    spawnEmotions();
    const spawnInterval = setInterval(spawnEmotions, 10000);
    return () => clearInterval(spawnInterval);
  }, []);

  const handleCollectEmotion = (emotion) => {
    if (!collectedEmotions.find(e => e.id === emotion.id)) {
      const updated = [...collectedEmotions, emotion];
      setCollectedEmotions(updated);
      setStorage('collectedEmotions', updated);
      alert(`¡Has recogido la emoción: ${emotion.name}!`);
    }
    setAvailableEmotions(availableEmotions.filter(e => e.id !== emotion.id));
  };

  const handleViewLegend = (emotion) => {
    setSelectedEmotion(emotion);
  };

  return (
    <div className="p-6 bg-gradient-to-br from-blue-300 to-purple-400 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cubes.png')" }}></div>

      <h2 className="text-3xl font-bold text-center mb-6 text-white drop-shadow-lg relative z-10">Explora y Recoge Emociones</h2>

      <div className="text-center mb-6 bg-white bg-opacity-90 p-4 rounded-lg shadow-xl relative z-10 border-2 border-black">
        <p className="text-gray-800 font-semibold">Emociones recogidas: <span className="text-black">{collectedEmotions.length}</span>/<span className="text-black">{emotionsData.length}</span></p>
        {collectedEmotions.length > 0 && (
          <div className="mt-3">
            <h3 className="text-lg font-semibold mb-2 text-gray-800">Tu Colección:</h3>
            <div className="flex flex-wrap justify-center">
              {collectedEmotions.map(emotion => (
                <span
                  key={emotion.id}
                  className="bg-black text-white text-sm px-3 py-1 rounded-full m-1 cursor-pointer hover:bg-gray-800 transition-colors shadow-md"
                  onClick={() => handleViewLegend(emotion)}
                >
                  {emotion.name}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
        {availableEmotions.map(emotion => (
          <EmotionCard key={emotion.id} emotion={emotion} onCollect={handleCollectEmotion} />
        ))}
      </div>

      {selectedEmotion && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full relative shadow-2xl border-2 border-black">
            <button
              onClick={() => setSelectedEmotion(null)}
              className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 text-2xl font-bold"
            >
              &times;
            </button>
            <EmotionLegend emotion={selectedEmotion} />
          </div>
        </div>
      )}
    </div>
  );
};

export default GameView;
