import React, { useEffect, useRef, useState } from "react";
import * as tmImage from "@teachablemachine/image";
import { saveIADetections, getIADetections } from "../utils/iastorage";
import { motion } from "framer-motion";

const MODEL_URL = "https://teachablemachine.withgoogle.com/models/g2J4VlQca/";

export default function ReconocimientoIA({ goToResumen }) {
  const webcamRef = useRef(null);
  const webcamInstance = useRef(null);
  const modelRef = useRef(null);
  const predictionIntervalRef = useRef(null);
  const isPredictingRef = useRef(false);
  const labelCountsRef = useRef(getIADetections());

  const [labelCounts, setLabelCounts] = useState(labelCountsRef.current);
  const [currentEmotion, setCurrentEmotion] = useState(null);

  useEffect(() => {
    initModel();

    return () => {
      stopWebcam();
    };
  }, []);

  const initModel = async () => {
    try {
      const modelURL = MODEL_URL + "model.json";
      const metadataURL = MODEL_URL + "metadata.json";

      const model = await tmImage.load(modelURL, metadataURL);
      modelRef.current = model;

      const webcam = new tmImage.Webcam(160, 160, true);
      await webcam.setup();
      await webcam.play();
      webcamInstance.current = webcam;

      if (webcamRef.current) {
        webcamRef.current.innerHTML = "";
        webcamRef.current.appendChild(webcam.canvas);
      }

      startPredictionLoop();
    } catch (error) {
      console.error("Error iniciando modelo o cámara:", error);
    }
  };

  const startPredictionLoop = () => {
    const model = modelRef.current;
    const webcam = webcamInstance.current;
    if (!model || !webcam) return;

    predictionIntervalRef.current = setInterval(async () => {
      if (isPredictingRef.current) return;

      isPredictingRef.current = true;

      try {
        webcam.update();

        const predictions = await model.predict(webcam.canvas);
        const top = predictions.reduce((a, b) =>
          a.probability > b.probability ? a : b
        );

        setCurrentEmotion((prev) =>
          prev !== top.className ? top.className : prev
        );

        const updated = {
          ...labelCountsRef.current,
          [top.className]: (labelCountsRef.current[top.className] || 0) + 1,
        };

        labelCountsRef.current = updated;
        setLabelCounts(updated);
      } catch (error) {
        console.error("Error en predicción:", error);
      } finally {
        isPredictingRef.current = false;
      }
    }, 1000);
  };

  const stopWebcam = () => {
    const webcam = webcamInstance.current;

    if (predictionIntervalRef.current) {
      clearInterval(predictionIntervalRef.current);
      predictionIntervalRef.current = null;
    }

    if (webcam && webcam.stream) {
      webcam.stop();
      webcam.stream.getTracks().forEach((t) => t.stop());
    }

    saveIADetections(labelCountsRef.current);
  };

  const total = Object.values(labelCounts).reduce((a, b) => a + b, 0);
  const topEmotion = Object.entries(labelCounts).sort((a, b) => b[1] - a[1])[0]?.[0];

  const handleGoToResumen = () => {
    stopWebcam();
    goToResumen();
  };

  return (
    <div className={`panel glass ${topEmotion ? `theme-${topEmotion}` : ""}`}>
      <motion.h2
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="title"
      >
        Reconocimiento de emociones (IA)
      </motion.h2>

      <div className="webcam-wrap">
        <div ref={webcamRef} className="webcam-canvas" />
      </div>

      <div className="status">
        Emoción detectada: <strong>{currentEmotion || "..."}</strong>
      </div>

      <div className="actions">
        <motion.button
          whileTap={{ scale: 0.96 }}
          className="btn danger"
          onClick={stopWebcam}
        >
          Detener detección
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.96 }}
          className="btn primary"
          onClick={handleGoToResumen}
        >
          Ver resumen de emociones
        </motion.button>
      </div>
    </div>
  );
}