// src/components/DiaryView.jsx
import React, { useMemo, useState } from "react";
import { avatarForEmotion } from "../assets/emotions"; // ✅ usar la función
import { detectEmotion, normalizeDiaryItem } from "../utils/iaCoach";
import { setStorage } from "../utils/storage";

export default function DiaryView({ diaryEntries = [], onAddEntry, onDeleteEntry }) {
  const [text, setText] = useState("");

  // Detección en vivo para darle feedback al usuario
  const liveEmotion = useMemo(() => (text ? detectEmotion(text) : null), [text]);

  const handleSave = () => {
    const t = text.trim();
    if (!t) return;
    const item = normalizeDiaryItem({ text: t, ts: Date.now(), emotion: detectEmotion(t) });
    if (onAddEntry) onAddEntry(item);
    setText("");
  };

  const handleDelete = (idx) => {
    if (!onDeleteEntry) return;
    if (!window.confirm("¿Eliminar esta entrada del diario?")) return;
    onDeleteEntry(idx);
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Editor rápido */}
      <div style={{ display: "grid", gap: 8 }}>
        <textarea
          placeholder="Escribe una entrada… (ej: hoy me sentí ansiosa y sin energía)"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          style={{
            borderRadius: 10,
            border: "1px solid #e1e6ff",
            padding: 10,
            outline: "none",
          }}
        />
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {liveEmotion && (
            <span
              style={{
                padding: "6px 10px",
                borderRadius: 999,
                border: "1px solid #e1e6ff",
                background: "#f0f3ff",
                color: "#3245a1",
                fontSize: 13,
              }}
            >
              Emoción detectada: <b>{liveEmotion}</b>
            </span>
          )}
          <button
            onClick={handleSave}
            style={{
              marginLeft: "auto",
              border: "none",
              padding: "10px 12px",
              borderRadius: 10,
              background: "#4666ff",
              color: "#fff",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            Guardar entrada
          </button>
        </div>
      </div>

      {/* Lista visual */}
      <div style={{ display: "grid", gap: 8 }}>
        {(!diaryEntries || diaryEntries.length === 0) && (
          <div style={{ color: "#667" }}>Aún no hay entradas.</div>
        )}

        {diaryEntries?.map((e, i) => {
          const emo = (e?.emotion || "neutro").toLowerCase();
          const when = new Date(e?.ts || Date.now()).toLocaleString();
          return (
            <div
              key={i}
              style={{
                display: "flex",
                gap: 10,
                alignItems: "flex-start",
                border: "1px solid #e8ebf3",
                borderRadius: 12,
                padding: 10,
                background: "#fff",
              }}
            >
              <img
                src={avatarForEmotion(emo)}  // ✅ cambio clave
                alt={emo}
                style={{
                  width: 56,
                  height: 56,
                  objectFit: "cover",
                  borderRadius: 10,
                  border: "1px solid #e6e8ee",
                }}
              />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, color: "#667" }}>
                  {when} — <b>{emo}</b>
                </div>
                <div style={{ whiteSpace: "pre-wrap" }}>{e?.text || ""}</div>
              </div>
              {onDeleteEntry && (
                <button
                  onClick={() => handleDelete(i)}
                  title="Eliminar"
                  style={{
                    border: "1px solid #e5e8f0",
                    background: "#fff",
                    borderRadius: 8,
                    padding: "6px 10px",
                    cursor: "pointer",
                  }}
                >
                  Eliminar
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
