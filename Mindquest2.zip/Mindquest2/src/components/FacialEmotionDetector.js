import React, { useRef, useEffect, useState } from 'react';
import * as faceapi from 'face-api.js';

const FaceEmotionDetector = ({ onEmotionDetected }) => {
  const videoRef = useRef(null);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [videoStarted, setVideoStarted] = useState(false);

  useEffect(() => {
    const loadModels = async () => {
      const MODEL_URL = process.env.PUBLIC_URL + '/models';
      try {
        await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
        await faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL);
        setModelsLoaded(true);
        console.log('Modelos cargados');
      } catch (error) {
        console.error('Error al cargar los modelos:', error);
      }
    };
    loadModels();
  }, []);

  useEffect(() => {
    if (!modelsLoaded) return;

    const startVideo = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play();
            setVideoStarted(true);
          };
        }
      } catch (error) {
        console.error('No se pudo acceder a la cámara:', error);
      }
    };

    startVideo();
  }, [modelsLoaded]);

  useEffect(() => {
    if (!modelsLoaded || !videoRef.current || !videoStarted) return;

    const interval = setInterval(async () => {
      try {
        const result = await faceapi
          .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceExpressions();

        if (result && result.expressions) {
          const sorted = Object.entries(result.expressions).sort((a, b) => b[1] - a[1]);
          const [topEmotion, confidence] = sorted[0];
          if (confidence > 0.6) {
            onEmotionDetected(topEmotion);
            console.log(`Emoción detectada: ${topEmotion} (${confidence.toFixed(2)})`);
          }
        }
      } catch (error) {
        console.error('Error durante la detección facial:', error);
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [modelsLoaded, videoStarted, onEmotionDetected]);

  return (
    <div className="my-4 text-center">
      <p className="mb-2">Reconocimiento facial activo</p>
      <video
        ref={videoRef}
        autoPlay
        muted
        playsInline
        width="320"
        height="240"
        style={{ borderRadius: '8px', backgroundColor: 'black' }}
      />
    </div>
  );
};

export default FaceEmotionDetector;
