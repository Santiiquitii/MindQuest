import React from 'react';

const HelplineView = () => {
  const helplines = [
    {
      name: "Línea 141",
      description: "Instituto Colombiano de Bienestar Familiar (ICBF).",
      phone: "141",
    },
    {
      name: "Línea 106",
      description: "Ayuda psicológica para jóvenes.",
      phone: "106",
    },
    {
      name: "Línea 155",
      description: "Línea Púrpura: atención a mujeres víctimas de violencia.",
      phone: "155",
    },
    {
      name: "Línea 192",
      description: "Ministerio de Salud y Protección Social.",
      phone: "192",
    },
  ];

  const ibtiLines = [
    {
      grade: "Grados 7° y 11°",
      name: "Maira Quiñonez",
    },
    {
      grade: "Grados 8° y 9°",
      name: "Karen Lorena Mendieta",
    },
    {
      grade: "Grados 6° y 10°",
      name: "Nélida Torres",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-indigo-50 px-6 py-8">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-3">
          Líneas de Atención en Colombia
        </h2>

        <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
          Si necesitas hablar con alguien, estas líneas pueden ayudarte y orientarte.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-12">
          {helplines.map((line, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-5 border-l-4 border-blue-500"
            >
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                {line.name}
              </h3>
              <p className="text-gray-600 mb-3">{line.description}</p>
              <p className="text-blue-600 font-bold text-lg">
                Teléfono: {line.phone}
              </p>
            </div>
          ))}
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg p-6 md:p-8 border border-blue-100">
          <h3 className="text-2xl md:text-3xl font-bold text-center text-gray-800 mb-2">
            LÍNEAS DE ATENCIÓN IBTI
          </h3>

          <p className="text-center text-gray-600 mb-6">
            Profesionales asignados según el grado.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {ibtiLines.map((item, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-white to-blue-50 rounded-2xl shadow-md p-5 border border-blue-100 text-center hover:-translate-y-1 hover:shadow-lg transition-all duration-300"
              >
                <p className="text-lg font-bold text-gray-800 mb-3">
                  {item.grade}
                </p>
                <p className="text-gray-700 font-medium mb-2">{item.name}</p>

                {item.email ? (
                  <a
                    href={`mailto:${item.email}`}
                    className="text-blue-600 font-medium break-words hover:underline"
                  >
                    {item.email}
                  </a>
                ) : (
                  <p className="text-gray-500 italic">Correo no disponible</p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 rounded-2xl bg-amber-50 border border-amber-200 p-5 shadow-sm">
            <p className="text-gray-700 leading-relaxed">
              <span className="font-bold text-amber-700">Recomendación:</span>{" "}
              Para el proceso de psicología, cada estudiante deberá solicitar la cita,
              según su división, con la psicóloga correspondiente a través de la
              plataforma de Gnosoft.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelplineView;