import React from 'react';

const ActivityCard = ({ activity, onSelect }) => {
  const handleClick = () => {
    if (activity.url) {
      window.open(activity.url, '_blank');
    } else {
      onSelect(activity.activity); // Solo si no hay URL
    }
  };

  return (
    <div
      onClick={handleClick}
      className="p-4 bg-white rounded-lg shadow-md hover:shadow-lg cursor-pointer transition duration-300"
    >
      <h4 className="text-lg font-semibold mb-2 text-gray-800">{activity.activity}</h4>
      {activity.description && (
        <p className="text-gray-600 text-sm">{activity.description}</p>
      )}
      {activity.url && (
        <p className="text-blue-600 text-sm mt-2 underline">Haz clic para abrir</p>
      )}
    </div>
  );
};

export default ActivityCard;
