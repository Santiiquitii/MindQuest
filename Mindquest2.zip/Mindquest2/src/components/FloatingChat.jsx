// src/components/FloatingChat.jsx
import { useState } from 'react';
import ChatBotWidget from './ChatBotWidget';
import './floatingChat.css';

export default function FloatingChat() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* 💬 Botón flotante de Sísifo */}
      <button
        className="mq-fab"
        aria-label={open ? 'Cerrar chat de Sísifo' : 'Abrir chat de Sísifo'}
        onClick={() => setOpen(o => !o)}
        title={open ? 'Cerrar chat de Sísifo' : 'Hablar con Sísifo'}
      >
        <span className="mq-fab-icon">💜</span>
      </button>

      {/* 📩 Panel del chat */}
      {open && (
        <div className="mq-panel">
          <div className="mq-panel-header">
            <div className="mq-title">🤖 Sísifo — Tu acompañante emocional</div>
            <button
              className="mq-close"
              onClick={() => setOpen(false)}
              title="Cerrar"
            >
              ✕
            </button>
          </div>

          <div className="mq-panel-body">
            <ChatBotWidget />
          </div>
        </div>
      )}
    </>
  );
}
