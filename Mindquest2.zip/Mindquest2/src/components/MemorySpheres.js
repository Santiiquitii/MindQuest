// src/components/MemorySpheres.jsx
import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const COLORS = {
  alegria: "#fbbf24",
  tristeza: "#60a5fa",
  ira: "#f87171",
  miedo: "#a78bfa",
  amor: "#fb7185",
  sorpresa: "#34d399",
  neutro: "#94a3b8",
};

export default function MemorySpheres({ collectedEmotions = [], onClear }) {
  const [items, setItems] = React.useState([]);

  React.useEffect(() => {
    // normaliza la lista existente a {id, mood}
    const normalized = collectedEmotions.map((e, i) => {
      const mood = typeof e === "string" ? e : e?.mood || e?.label || "neutro";
      return { id: i, mood };
    });
    setItems(normalized);
  }, [collectedEmotions]);

  const handleClear = () => {
    if (!onClear) return;
    if (window.confirm("¿Quieres limpiar todas las esferas?")) onClear();
  };

  return (
    <section className="panel glass">
      {/* Header con botón Limpiar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <div>
          <h3 className="title" style={{ marginBottom: 6 }}>Mis Esferas de Emoción</h3>
          <p className="muted" style={{ marginTop: 0 }}>
            Cada emoción se convierte en una esfera y cae dentro del frasco.
          </p>
        </div>

        {onClear && (
          <button
            onClick={handleClear}
            className="nav-btn"
            title="Limpiar esferas"
            style={{ background: "#ef4444", borderColor: "#ef4444" }}
          >
            Limpiar
          </button>
        )}
      </div>

      <div className="jar-wrap">
        <div className="jar">
          <div className="jar-mouth" />
          <div className="jar-inner">
            <AnimatePresence initial={false}>
              {items.length === 0 ? (
                <div className="muted" key="empty">
                  Aún no hay esferas. Registra tu primera emoción ✨
                </div>
              ) : (
                items.map((it) => <Sphere key={it.id} mood={it.mood} />)
              )}
            </AnimatePresence>
          </div>
          <div className="jar-gloss" />
        </div>
      </div>
    </section>
  );
}

function Sphere({ mood }) {
  const color = COLORS[mood] || COLORS.neutro;
  const x = Math.floor(Math.random() * 85) + 7;   // 7% - 92% del ancho
  const size = 22 + Math.floor(Math.random() * 8); // 22–30px

  return (
    <motion.div
      className="sphere-in-jar"
      initial={{ y: -80, x: `${x}%`, opacity: 0, scale: 0.8 }}
      animate={{ y: 0, opacity: 1, scale: 1 }}
      exit={{ y: -40, opacity: 0, scale: 0.8 }}
      transition={{ type: "spring", stiffness: 170, damping: 16 }}
      title={mood[0].toUpperCase() + mood.slice(1)}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle at 30% 30%, ${color}, rgba(255,255,255,0.06))`,
        boxShadow: `0 6px 16px ${hexToRgba(color, 0.35)}, inset 0 8px 14px rgba(255,255,255,0.35)`,
        border: "1px solid rgba(255,255,255,0.22)",
        borderRadius: 999,
        position: "relative",
      }}
    >
      <div className="sphere-gloss" />
    </motion.div>
  );
}

function hexToRgba(hex, alpha = 1) {
  const c = hex.replace("#", "");
  const n = parseInt(c, 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
