import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const EMOTIONS = [
  { key: "alegria", label: "Alegría", emoji: "😊", color: "#fbbf24" },
  { key: "tristeza", label: "Tristeza", emoji: "😔", color: "#60a5fa" },
  { key: "ira",      label: "Furia",    emoji: "😡", color: "#f87171" },
  { key: "miedo",    label: "Temor",    emoji: "😨", color: "#a78bfa" },
  { key: "amor",     label: "Amor",     emoji: "🥰", color: "#fb7185" },
  { key: "sorpresa", label: "Sorpresa", emoji: "😮", color: "#34d399" },
  { key: "neutro",   label: "Neutro",   emoji: "😶", color: "#94a3b8" },
];

export default function EmotionInput({ onEmotionSelected }) {
  const [hovered, setHovered] = React.useState(null);
  const [pulse, setPulse] = React.useState(null);

  const select = (emo) => {
    setPulse(emo.key);
    onEmotionSelected?.(emo.key);
    // feedback háptico (en móviles que lo soporten)
    if (window.navigator?.vibrate) window.navigator.vibrate(10);
    setTimeout(() => setPulse(null), 300);
  };

  return (
    <div className="glass panel center">
      <h3 className="title">¿Cómo te sientes hoy?</h3>

      <div className="chip-row">
        {EMOTIONS.map((e) => (
          <motion.button
            key={e.key}
            onClick={() => select(e)}
            className="chip"
            style={{ background: e.color }}
            whileHover={{ y: -6, scale: 1.06 }}
            whileTap={{ scale: 0.94 }}
            onMouseEnter={() => setHovered(e.key)}
            onMouseLeave={() => setHovered(null)}
          >
            <span className="chip-emoji" aria-hidden>{e.emoji}</span>
            <span className="chip-label">{e.label}</span>

            <AnimatePresence>
              {pulse === e.key && (
                <motion.span
                  className="chip-ping"
                  initial={{ opacity: 0, scale: 0.6 }}
                  animate={{ opacity: 0.5, scale: 1.35 }}
                  exit={{ opacity: 0, scale: 1.5 }}
                  transition={{ duration: 0.3 }}
                />
              )}
            </AnimatePresence>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {hovered && (
          <motion.div
            className="hint"
            initial={{ y: 6, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 6, opacity: 0 }}
          >
            Toca para registrar tu emoción
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}