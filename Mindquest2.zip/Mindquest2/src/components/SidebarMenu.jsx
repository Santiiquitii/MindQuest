import React, { useState } from "react";
import "./SidebarMenu.css";

export default function SidebarMenu({ currentPage, setCurrentPage, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNavigate = (page) => {
    setCurrentPage(page);
    setMenuOpen(false);
  };

  return (
    <>
      <nav className="mq-topbar glass">
        <div className="mq-brand">MindQuest</div>

        <button
          className={`mq-menu-btn ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Abrir menú"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </nav>

      {menuOpen && (
        <div
          className="mq-overlay"
          onClick={() => setMenuOpen(false)}
        ></div>
      )}

      <aside className={`mq-sidebar ${menuOpen ? "open" : ""}`}>
        <button
          onClick={() => handleNavigate("game")}
          className={currentPage === "game" ? "active" : ""}
        >
          Explorar
        </button>

        <button
          onClick={() => handleNavigate("diary")}
          className={currentPage === "diary" ? "active" : ""}
        >
          Diario
        </button>

        <button
          onClick={() => handleNavigate("activities")}
          className={currentPage === "activities" ? "active" : ""}
        >
          Actividades
        </button>

        <button
          onClick={() => handleNavigate("minigames")}
          className={currentPage === "minigames" ? "active" : ""}
        >
          Minijuegos
        </button>

        <button
          onClick={() => handleNavigate("progress")}
          className={currentPage === "progress" ? "active" : ""}
        >
          Progreso
        </button>

        <button
          onClick={() => handleNavigate("ia")}
          className={currentPage === "ia" ? "active" : ""}
        >
          Reconocimiento de Emociones
        </button>

        <button
          onClick={() => handleNavigate("helplines")}
          className={currentPage === "helplines" ? "active" : ""}
        >
          Ayuda
        </button>

        <button
          onClick={() => handleNavigate("profile")}
          className={currentPage === "profile" ? "active" : ""}
        >
          Perfil
        </button>

        <button onClick={onLogout} className="logout-btn">
          Salir
        </button>
      </aside>
    </>
  );
}