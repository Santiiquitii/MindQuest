import React, { useState } from "react";

const AVATARS = [
  { id: "a1", label: "Explorador/a", emoji: "🧭" },
  { id: "a2", label: "Artista",      emoji: "🎨" },
  { id: "a3", label: "Soñador/a",    emoji: "🌙" },
  { id: "a4", label: "Atleta",       emoji: "🏃‍♀️" },
  { id: "a5", label: "Científico/a", emoji: "🧪" },
  { id: "a6", label: "Musical",      emoji: "🎵" },
];

const COLORS = ["#fbbf24", "#60a5fa", "#f87171", "#a78bfa", "#34d399", "#fb7185", "#94a3b8"];

export default function AvatarSelector({ onProfileCreated }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [avatar, setAvatar] = useState(AVATARS[0].id);
  const [color, setColor] = useState(COLORS[0]);
  const [error, setError] = useState("");

  const sel = AVATARS.find((a) => a.id === avatar);

  const create = () => {
    if (!name.trim()) { setError("Por favor, escribe tu nombre."); return; }
    setError("");
    onProfileCreated?.({
      name: name.trim(),
      age: age ? Number(age) : null,
      avatar: sel,
      color,
      createdAt: Date.now(),
    });
  };

  return (
    <section className="panel glass avatar-wrap">
      <h2 className="title" style={{ textAlign: "center" }}>Crea tu personaje</h2>

      <div className="avatar-layout">
        {/* PREVIEW */}
        <div className="avatar-preview">
          <div className="preview-card" style={{ borderColor: color }}>
            <div className="preview-emoji" style={{ background: color + "33" }}>
              {sel.emoji}
            </div>
            <div className="preview-info">
              <div className="preview-name">{name || "Tu nombre"}</div>
              <div className="preview-role">{sel.label}</div>
            </div>
          </div>

          <div className="color-row">
            {COLORS.map((c) => (
              <button
                key={c}
                className={`color-dot ${c === color ? "active" : ""}`}
                style={{ background: c }}
                onClick={() => setColor(c)}
                aria-label={`Color ${c}`}
              />
            ))}
          </div>
        </div>

        {/* FORM */}
        <div className="avatar-form">
          <label className="input-label">Nombre</label>
          <input
            className="input"
            placeholder="Escribe tu nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <label className="input-label">Edad (opcional)</label>
          <input
            className="input"
            placeholder="Ej. 12"
            type="number"
            min="5"
            max="99"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />

          <label className="input-label">Elige tu estilo</label>
          <div className="avatar-grid">
            {AVATARS.map((a) => (
              <button
                key={a.id}
                className={`avatar-card ${a.id === avatar ? "selected" : ""}`}
                onClick={() => setAvatar(a.id)}
              >
                <span className="avatar-emoji">{a.emoji}</span>
                <span className="avatar-label">{a.label}</span>
              </button>
            ))}
          </div>

          {error && <div className="form-error">{error}</div>}

          <div className="form-actions">
            <button className="btn btn-primary" onClick={create}>
              Guardar y continuar
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}