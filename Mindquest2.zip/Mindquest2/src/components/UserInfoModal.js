import React from 'react';
import { getStorage } from '../utils/storage';

const UserInfoModal = ({ onClose }) => {
  const userGender = getStorage('userGender');
  const userAvatar = getStorage('userAvatar');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 max-w-sm w-full relative shadow-2xl border-2 border-black">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 text-2xl font-bold"
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold text-center mb-4">Información del Usuario</h2>
        {userAvatar && (
          <div className="flex justify-center mb-4">
            <img src={userAvatar} alt="Tu Avatar" className="w-24 h-24 rounded-full border-4 border-black" />
          </div>
        )}
        <p className="text-center text-gray-700">Género: {userGender === 'female' ? 'Mujer' : 'Hombre'}</p>
        {/* Aquí podrías añadir más información del usuario si la tuvieras */}
      </div>
    </div>
  );
};

export default UserInfoModal;