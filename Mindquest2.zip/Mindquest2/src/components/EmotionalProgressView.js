import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { getStorage } from "../utils/storage";

// Orden y mapeo de nombres bonitos
const EMOTIONS = [
  { key: "alegria",  label: "Alegría"  },
  { key: "tristeza", label: "Tristeza" },
  { key: "ira",      label: "Furia"    },
  { key: "miedo",    label: "Temor"    },
  { key: "amor",     label: "Amor"     },
  { key: "sorpresa", label: "Sorpresa" },
  { key: "neutro",   label: "Neutro"   },
];

// Normaliza un registro en { label, ts }
function normalizeEmotion(entry) {
  let key = "neutro";
  if (typeof entry === "string") {
    key = entry;
  } else if (entry && typeof entry === "object") {
    key = entry.mood || entry.label || entry.emotion || "neutro";
  }
  // timestamp si existe (ts | date | createdAt). Si no, null.
  let ts = null;
  if (entry && typeof entry === "object") {
    ts = entry.ts || entry.time || entry.timestamp || entry.date || entry.createdAt || null;
  }
  // Convierte strings de fecha a número
  if (typeof ts === "string") {
    const d = new Date(ts);
    ts = isNaN(d.getTime()) ? null : d.getTime();
  }
  return { label: key, ts };
}

export default function EmotionalProgressView({
  // opcionales desde App.jsx
  collectedEmotions: collectedFromProps = null,
  diaryEntries = [],
  onReset, // ← si llega, se muestra el botón
}) {
  // Fuente de datos: props si vienen, si no, storage (comportamiento previo)
  const raw = Array.isArray(collectedFromProps)
    ? collectedFromProps
    : (getStorage("collectedEmotions") || []);

  // Normaliza
  const normalized = raw.map(normalizeEmotion);

  // Rango: últimos 7 días si hay timestamps; si no hay, usamos todo.
  const now = Date.now();
  const sevenDays = 7 * 24 * 60 * 60 * 1000;
  const anyTs = normalized.some((e) => typeof e.ts === "number");

  const inRange = normalized.filter((e) =>
    anyTs ? (typeof e.ts === "number" ? now - e.ts <= sevenDays : false) : true
  );

  // Conteo por emoción
  const counts = EMOTIONS.reduce((acc, { key }) => ({ ...acc, [key]: 0 }), {});
  inRange.forEach((e) => {
    const key = (e.label || "neutro").toLowerCase();
    if (counts[key] !== undefined) counts[key] += 1;
    else counts["neutro"] += 1; // fallback seguro
  });

  // Data para Recharts (label visible + count)
  const data = EMOTIONS.map(({ key, label }) => ({
    label,
    count: counts[key],
  }));

  const total = data.reduce((a, b) => a + b.count, 0);

  const handleReset = () => {
    if (!onReset) return;
    const ok = window.confirm(
      "Esto borrará tu progreso (esferas y entradas del diario). ¿Deseas continuar?"
    );
    if (ok) onReset();
  };

  return (
    <section className="panel glass">
      {/* Header con botón de reinicio si está disponible */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h2 className="title" style={{ textAlign: "left", margin: 0 }}>Progreso Emocional</h2>
        {typeof onReset === "function" && (
          <button
            onClick={handleReset}
            className="nav-btn"
            title="Reiniciar progreso"
            style={{ background: "#ef4444", borderColor: "#ef4444" }}
          >
            Reiniciar
          </button>
        )}
      </div>

      {total === 0 ? (
        <p className="muted" style={{ textAlign: "center", marginTop: 8 }}>
          Aún no hay registros {anyTs ? "en los últimos 7 días" : ""}. Registra una emoción para ver tu progreso.
        </p>
      ) : (
        <div style={{ width: "100%", height: 320, marginTop: 8 }}>
          <ResponsiveContainer>
            <BarChart data={data} margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="label" />
              <YAxis allowDecimals={false} />
              <Tooltip
                formatter={(value, name) => [value, name === "count" ? "Cantidad" : name]}
                labelFormatter={(l) => l}
              />
              <Bar dataKey="count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="muted" style={{ textAlign: "center", marginTop: 8 }}>
        {anyTs ? "Mostrando últimos 7 días" : "Mostrando historial (sin fecha registrada)"}
      </p>
    </section>
  );
}
