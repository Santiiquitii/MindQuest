// src/components/UserProfile.jsx
import React, { useEffect, useState } from "react";
import { avatarForEmotion, EMOTION_AVATARS } from "../assets/emotions";
import { getStorage, setStorage } from "../utils/storage"; // tus helpers

export default function UserProfile({ lastEmotion = "alegria" }) {
  // Estado de configuración
  const [autoAvatar, setAutoAvatar] = useState(getStorage("profile:autoAvatar") ?? true);
  const [fixedAvatarKey, setFixedAvatarKey] = useState(
    getStorage("profile:fixedAvatarKey") || "alegria"
  );

  // Datos del usuario (nombre y año de nacimiento guardados en localStorage)
  const [name, setName] = useState(getStorage("profile:name") || "Usuario");
  const [birthYear, setBirthYear] = useState(getStorage("profile:birthYear") || 2000);

  useEffect(() => setStorage("profile:autoAvatar", autoAvatar), [autoAvatar]);
  useEffect(() => setStorage("profile:fixedAvatarKey", fixedAvatarKey), [fixedAvatarKey]);
  useEffect(() => setStorage("profile:name", name), [name]);
  useEffect(() => setStorage("profile:birthYear", birthYear), [birthYear]);

  // Calcular edad
  const age = birthYear ? new Date().getFullYear() - birthYear : null;

  const currentSrc = autoAvatar
    ? avatarForEmotion(lastEmotion)
    : EMOTION_AVATARS[fixedAvatarKey] || avatarForEmotion("alegria");

  return (
    <div style={s.card}>
      <div style={s.header}>
        <img src={currentSrc} alt="Avatar" style={s.avatar} />
        <div>
          <div style={s.title}>{name}</div>
          <div style={s.subtitle}>
            {age ? `${age} años — ` : ""}Avatar {autoAvatar ? "automático" : "fijo"}
            {autoAvatar ? ` (según: ${lastEmotion})` : ""}
          </div>
        </div>
      </div>

      <label style={s.switch}>
        <input
          type="checkbox"
          checked={autoAvatar}
          onChange={(e) => setAutoAvatar(e.target.checked)}
        />
        <span>Usar avatar automático por emoción</span>
      </label>

      {!autoAvatar && (
        <>
          <div style={{ fontWeight: 600, margin: "8px 0 6px" }}>Elige tu avatar:</div>
          <div style={s.grid}>
            {Object.keys(EMOTION_AVATARS)
              .filter((k) => k !== "neutro") // 👈 quitar neutro
              .map((k) => (
                <button
                  key={k}
                  onClick={() => setFixedAvatarKey(k)}
                  style={{
                    ...s.option,
                    outline:
                      fixedAvatarKey === k ? "2px solid #6f8bff" : "1px solid #e5e8f0",
                  }}
                  title={k}
                >
                  <img src={EMOTION_AVATARS[k]} alt={k} style={s.thumb} />
                  <div style={s.k}>{k}</div>
                </button>
              ))}
          </div>
        </>
      )}

      {/* Inputs para editar nombre y año */}
      <div style={{ marginTop: 12 }}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>Información personal</div>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nombre"
          style={s.input}
        />
        <input
          type="number"
          value={birthYear}
          onChange={(e) => setBirthYear(parseInt(e.target.value) || "")}
          placeholder="Año de nacimiento"
          style={s.input}
        />
      </div>
    </div>
  );
}

const s = {
  card: {
    border: "1px solid #e8ebf3",
    borderRadius: 16,
    padding: 12,
    background: "#fff",
  },
  header: { display: "flex", alignItems: "center", gap: 12, marginBottom: 8 },
  avatar: {
    width: 72,
    height: 72,
    objectFit: "cover",
    borderRadius: 12,
    border: "1px solid #e6e8ee",
  },
  title: { fontSize: 18, fontWeight: 700 },
  subtitle: { fontSize: 12, color: "#667" },
  switch: { display: "flex", alignItems: "center", gap: 8, marginTop: 8 },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(110px, 1fr))",
    gap: 8,
    marginTop: 6,
  },
  option: {
    borderRadius: 12,
    padding: 8,
    background: "#fafbff",
    cursor: "pointer",
  },
  thumb: {
    width: "100%",
    height: 88,
    objectFit: "cover",
    borderRadius: 8,
    border: "1px solid #e6e8ee",
  },
  k: { fontSize: 12, marginTop: 6, color: "#445", textTransform: "capitalize" },
  input: {
    display: "block",
    width: "100%",
    marginTop: 6,
    padding: 8,
    border: "1px solid #ddd",
    borderRadius: 8,
  },
};
