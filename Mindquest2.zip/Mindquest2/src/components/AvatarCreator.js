import React, { useState } from 'react';
import { createStorage } from '../utils/storage';

const AvatarCreator = ({ onAvatarCreated }) => {
  const [avatarUrl, setAvatarUrl] = createStorage('userAvatar', '');
  const [inputUrl, setInputUrl] = useState('');

  const handleCreateAvatar = () => {
    // Aquí iría la lógica para integrar con Bitmoji o similar
    // Por ahora, usaremos una URL de ejemplo o la que el usuario ponga
    if (inputUrl) {
      setAvatarUrl(inputUrl);
      onAvatarCreated(inputUrl);
    } else {
      // URL de Bitmoji de ejemplo (requiere integración real)
      const defaultAvatar = 'https://sdk.bitmoji.com/render/panel/d1111111-1111-1111-1111-111111111111-v1.png?scale=1&width=240&height=240&pose_id=1';
      setAvatarUrl(defaultAvatar);
      onAvatarCreated(defaultAvatar);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-sm mx-auto mt-10">
      <h2 className="text-2xl font-bold text-center mb-4">Crea tu Avatar</h2>
      {avatarUrl && (
        <div className="flex justify-center mb-4">
          <img src={avatarUrl} alt="Tu Avatar" className="w-32 h-32 rounded-full border-4 border-black" />
        </div>
      )}
      <input
        type="text"
        placeholder="Pega aquí la URL de tu Bitmoji (o deja vacío)"
        value={inputUrl}
        onChange={(e) => setInputUrl(e.target.value)}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black transition"
      />
      <button
        onClick={handleCreateAvatar}
        className="w-full mt-4 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors"
      >
        Guardar Avatar
      </button>
    </div>
  );
};

export default AvatarCreator;