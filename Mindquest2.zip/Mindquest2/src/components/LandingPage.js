import React from "react";

export default function LandingPage({ onStart }) {
  return (
    <section className="hero-wrap">
      <div className="hero glass">
        <div className="hero-badges">
          <span className="badge">Bienvenido/a</span>
          <span className="badge badge-soft">MindQuest</span>
        </div>

        <h1 className="hero-title">Comienza tu aventura emocional</h1>
        <p className="hero-sub">
          Registra cómo te sientes, crea tu avatar y explora actividades
          diseñadas para acompañarte cada día.
        </p>

        <div className="hero-cta">
          <button className="btn btn-xl btn-primary" onClick={onStart}>
            🚀 Comenzar aventuras
          </button>
        </div>

        <div className="hero-features">
          <div className="feat">
            <div className="feat-emoji">🧠</div>
            <div className="feat-text">
              <b>IA Emocional</b>
              <span>Reconoce emociones con tu cámara</span>
            </div>
          </div>
          <div className="feat">
            <div className="feat-emoji">📔</div>
            <div className="feat-text">
              <b>Diario</b>
              <span>Escribe recuerdos y pensamientos</span>
            </div>
          </div>
          <div className="feat">
            <div className="feat-emoji">🎮</div>
            <div className="feat-text">
              <b>Minijuegos</b>
              <span>Aprende jugando</span>
            </div>
          </div>
        </div>
      </div>

      {/* orbes decorativos suaves */}
      <div className="hero-orb orb-1" />
      <div className="hero-orb orb-2" />
      <div className="hero-orb orb-3" />
    </section>
  );
}