// src/components/IACoach.jsx
import React, { useState } from "react";
import { answerQuestion, recommendActivityForEmotion } from "../utils/iaCoach";
import { avatarForEmotion } from "../assets/emotions"; // opcional: para mostrar imagen

export default function IACoach({ diaryEntries = [] }) {
  const [q, setQ] = useState("");
  const [resp, setResp] = useState(null);

  const onAsk = () => {
    const trimmed = (q || "").trim();
    if (!trimmed) return;
    const r = answerQuestion(trimmed, diaryEntries);
    setResp(r);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      onAsk();
    }
  };

  const activity = resp ? recommendActivityForEmotion(resp.emotion) : null;

  return (
    <div
      style={{
        display: "grid",
        gap: 12,
        border: "1px solid #e6e8ee",
        borderRadius: 12,
        padding: 16,
        background: "#fff",
      }}
    >
      <h3 style={{ margin: 0 }}>IA Coach</h3>

      <div style={{ display: "grid", gap: 8 }}>
        <textarea
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Pregúntame algo: ej. ¿Qué hago cuando me siento ansiosa?"
          rows={3}
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 10,
            border: "1px solid #d9dce6",
            outline: "none",
          }}
        />
        <div style={{ display: "flex", gap: 8 }}>
          <button
            onClick={onAsk}
            style={{
              border: "none",
              padding: "10px 12px",
              borderRadius: 10,
              background: "#4666ff",
              color: "#fff",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            Preguntar
          </button>
          <div style={{ marginLeft: "auto", color: "#667", fontSize: 12 }}>
            Tip: <kbd>Ctrl</kbd>/<kbd>Cmd</kbd> + <kbd>Enter</kbd> para enviar
          </div>
        </div>
      </div>

      {resp && (
        <div
          style={{
            display: "grid",
            gap: 10,
            border: "1px solid #e1e6ff",
            background: "#f8f9ff",
            borderRadius: 10,
            padding: 12,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {/* Avatar opcional de la emoción */}
            <img
              src={avatarForEmotion(resp.emotion)}
              alt={resp.emotion}
              style={{
                width: 48,
                height: 48,
                objectFit: "cover",
                borderRadius: 10,
                border: "1px solid #e6e8ee",
              }}
            />
            <span
              style={{
                padding: "6px 10px",
                borderRadius: 999,
                border: "1px solid #e1e6ff",
                background: "#eef2ff",
                color: "#3245a1",
                fontSize: 13,
              }}
            >
              Emoción detectada: <b>{resp.emotion}</b>
            </span>
          </div>

          <div style={{ whiteSpace: "pre-wrap" }}>{resp.text}</div>

          {activity && (
            <div
              style={{
                borderTop: "1px dashed #d5dbff",
                paddingTop: 10,
                marginTop: 4,
              }}
            >
              <div style={{ fontWeight: 700, marginBottom: 4 }}>
                Sugerencia para {resp.emotion}:
              </div>
              <div style={{ fontWeight: 600 }}>{activity.title}</div>
              <div style={{ color: "#445" }}>{activity.description}</div>
              <div
                style={{
                  marginTop: 6,
                  fontSize: 12,
                  color: "#667",
                  border: "1px solid #e6e8ee",
                  borderRadius: 8,
                  display: "inline-block",
                  padding: "2px 8px",
                  background: "#fff",
                }}
              >
                {activity.tag}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
