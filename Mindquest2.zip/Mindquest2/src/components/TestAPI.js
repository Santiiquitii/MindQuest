import React, { useState } from 'react';
import axios from 'axios';

const TestAPI = () => {
  const [response, setResponse] = useState('');
  const [error, setError] = useState('');

  const probarConexion = async () => {
    try {
      const res = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: 'Hola, ¿me puedes responder?' }],
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.REACT_APP_OPENAI_KEY}`,
            'Content-Type': 'application/json',
          },
        }
      );

      setResponse(res.data.choices[0].message.content);
      setError('');
    } catch (err) {
      console.error(err);
      setError(err.response?.status + ': ' + (err.response?.data?.error?.message || 'Error de conexión'));
      setResponse('');
    }
  };

  return (
    <div className="p-4 max-w-xl mx-auto mt-10 border rounded shadow bg-white">
      <h2 className="text-xl font-bold mb-4">🔌 Prueba de conexión a la API</h2>
      <button
        onClick={probarConexion}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Probar conexión
      </button>
      {response && <p className="mt-4 text-green-600">✅ Respuesta: {response}</p>}
      {error && <p className="mt-4 text-red-600">❌ Error: {error}</p>}
    </div>
  );
};

export default TestAPI;
