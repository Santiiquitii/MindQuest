import React, { useState } from "react";
import { motion } from "framer-motion";
import logoITC from "../assets/logo-itc.png";

export default function AuthGate({ onAuthenticated }) {
  const [mode, setMode] = useState("login"); // 'login' | 'signup'
  const [username, setUsername] = useState("");
  const [pass, setPass] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e?.preventDefault();
    if (!username || !pass) return setError("Completa usuario y contraseña.");
    setLoading(true);
    setError("");

    try {
      await new Promise((r) => setTimeout(r, 600));
      onAuthenticated?.({
        username,
        key: {},
        vault: {},
      });
    } catch (err) {
      setError("No se pudo iniciar sesión. Inténtalo nuevamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-hero">
      <div className="auth-blob a" />
      <div className="auth-blob b" />
      <div className="auth-blob c" />

      <motion.div
        className="auth-card glass"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 120, damping: 16 }}
      >
        <div className="auth-header">
          <div
            className="auth-logo-itc-wrap"
            style={{
              display: "flex",
              justifyContent: "center",
              marginBottom: "8px",
            }}
          >
            <img
              src={logoITC}
              alt="Logo ITC"
              className="auth-logo-itc"
              style={{
                width: "58px",
                height: "58px",
                objectFit: "contain",
                mixBlendMode: "multiply",
                opacity: 0.92,
              }}
            />
          </div>

          <div className="auth-logo">
            <span className="logo-dot">🧠</span>
            <span className="logo-text">MindQuest</span>
          </div>

          <div className="auth-subtitle">
            Tu espacio seguro para explorar y regular emociones
          </div>
        </div>

        <div className="auth-tabs">
          <button
            className={`auth-tab ${mode === "login" ? "active" : ""}`}
            onClick={() => setMode("login")}
          >
            Iniciar sesión
          </button>
          <button
            className={`auth-tab ${mode === "signup" ? "active" : ""}`}
            onClick={() => setMode("signup")}
          >
            Crear cuenta
          </button>
        </div>

        <form onSubmit={submit} className="auth-form">
          <label className="auth-label">Usuario</label>
          <div className="auth-input-wrap">
            <input
              className="auth-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="tu_usuario"
              autoFocus
            />
            <span className="auth-input-icon">👤</span>
          </div>

          <label className="auth-label">Contraseña</label>
          <div className="auth-input-wrap">
            <input
              className="auth-input"
              type={showPass ? "text" : "password"}
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              placeholder="••••••••"
            />
            <button
              type="button"
              className="auth-eye"
              onClick={() => setShowPass((s) => !s)}
              title={showPass ? "Ocultar" : "Mostrar"}
            >
              {showPass ? "🙈" : "👁️"}
            </button>
          </div>

          {error && <div className="auth-error">{error}</div>}

          <button
            className="nav-btn auth-submit"
            disabled={loading}
            type="submit"
          >
            {loading ? "Entrando…" : mode === "login" ? "Entrar" : "Crear cuenta"}
          </button>

          <div className="auth-links">
            {mode === "login" ? (
              <span>
                ¿No tienes cuenta?{" "}
                <button
                  type="button"
                  className="auth-link"
                  onClick={() => setMode("signup")}
                >
                  Crear una
                </button>
              </span>
            ) : (
              <span>
                ¿Ya tienes cuenta?{" "}
                <button
                  type="button"
                  className="auth-link"
                  onClick={() => setMode("login")}
                >
                  Iniciar sesión
                </button>
              </span>
            )}
          </div>

          <div className="auth-footnote">
            Tus datos se guardan <b>cifrados</b> en este dispositivo.
          </div>
        </form>
      </motion.div>
    </div>
  );
}