// src/components/ChatBotWidget.jsx
import { useEffect, useMemo, useRef, useState } from 'react';
import { sendToBot } from '../utils/chatApi';

export default function ChatBotWidget() {
  const [input, setInput] = useState('');
  const [msgs, setMsgs] = useState([
    { from: 'Sísifo', text: 'Soy Sísifo 🌿, tu acompañante emocional. ¿Cómo te sientes hoy?' }
  ]);
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  const inputRef = useRef(null);

  const sessionId = useMemo(() => 'sisifo-' + Math.random().toString(36).slice(2, 10), []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, loading]);

  useEffect(() => { 
    inputRef.current?.focus();
  }, []);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const you = { from: 'tú', text };
    setMsgs(m => [...m, you]);
    setInput('');
    setLoading(true);

    try {
      const resp = await sendToBot(text, sessionId);
      // Compat: puede venir {respuesta, suggestion} o {respuesta, suggestions}
      const suggestions = resp.suggestions || (resp.suggestion ? [resp.suggestion] : []);
      const bot = { from: 'Sísifo', text: resp.respuesta, suggestions };
      setMsgs(m => [...m, bot]);
    } catch (e) {
      const baseUrl = import.meta.env.VITE_CHATBOT_URL || 'http://10.0.2.2:5000';
      setMsgs(m => [
       ...m,
      { from: 'Sísifo', text: `Ups, no pude conectar. Revisa que el bot esté activo y que la URL sea: ${baseUrl}` }
      ]);
} finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const openSuggestion = (sug) => {
    if (!sug?.route) return;
    if (typeof window !== 'undefined' && typeof window.mqNavigate === 'function') {
      window.mqNavigate(sug.route);
      return;
    }
    try {
      window.location.href = sug.route;
    } catch {
      setMsgs(m => [...m, { from: 'Sísifo', text: `No pude navegar automáticamente. Ve a: ${sug.route}` }]);
    }
  };

  return (
    <div className="p-3 rounded-xl border max-w-md space-y-3" style={{ background: '#fff' }}>
      {/* Encabezado de Sísifo */}
      <div style={{ textAlign: 'center', marginBottom: 4 }}>
        <div style={{ fontWeight: 700, color: '#6d28d9' }}>🤖 Sísifo</div>
        <div style={{ fontSize: 12, color: '#666' }}>Tu acompañante emocional</div>
      </div>

      {/* Mensajes */}
      <div className="space-y-2 max-h-80 overflow-auto" style={{ maxHeight: 320, paddingRight: 4 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ textAlign: m.from === 'tú' ? 'right' : 'left' }}>
            <div
              className="inline-block px-3 py-2 rounded-lg shadow-sm"
              style={{
                display: 'inline-block',
                padding: '8px 10px',
                borderRadius: 10,
                background: m.from === 'tú' ? '#e7f3ff' : '#f3f4f6',
                maxWidth: '92%',
                wordWrap: 'break-word',
              }}
            >
              <b>{m.from}:</b> {m.text}
            </div>

            {/* Botones de sugerencia (pueden ser varios) */}
            {m.from === 'Sísifo' && m.suggestions?.length > 0 && (
              <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {m.suggestions.map((sug, idx) => (
                  <button
                    key={idx}
                    className="px-3 py-2 rounded-lg border hover:shadow"
                    onClick={() => openSuggestion(sug)}
                    title={sug.route}
                    style={{
                      padding: '6px 10px',
                      borderRadius: 10,
                      border: '1px solid #ddd',
                      background: '#fff',
                      cursor: 'pointer'
                    }}
                  >
                    {sug.icon || '➡️'} {sug.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div style={{ opacity: 0.8, fontSize: 12, color: '#6b7280', marginTop: 6 }}>
            Sísifo está escribiendo…
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input + Enviar */}
      <div className="flex gap-2" style={{ display: 'flex', gap: 8 }}>
        <input
          ref={inputRef}
          className="flex-1 border rounded px-3 py-2"
          placeholder="Cuéntale a Sísifo cómo te sientes…"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          style={{ flex: 1, padding: 8, border: '1px solid #ddd', borderRadius: 10 }}
        />
        <button
          className="border rounded px-4 py-2"
          onClick={send}
          disabled={loading}
          style={{
            padding: '8px 12px',
            borderRadius: 10,
            border: '1px solid #ddd',
            background: loading ? '#f3f4f6' : '#6d28d9',
            color: loading ? '#666' : '#fff',
            cursor: loading ? 'not-allowed' : 'pointer'
          }}
        >
          {loading ? 'Enviando…' : 'Enviar'}
        </button>
      </div>
    </div>
  );
}
