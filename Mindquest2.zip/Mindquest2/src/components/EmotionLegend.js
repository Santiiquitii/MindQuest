import React from 'react';

const EmotionLegend = ({ emotion }) => {
  if (!emotion) return null;

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-md mx-auto mt-6">
      <h2 className="text-2xl font-bold text-center mb-4">{emotion.name}</h2>
      <p className="text-gray-700 mb-4">{emotion.description}</p>

      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">¿Cómo se da?</h3>
        <p className="text-gray-700">{emotion.howItHappens}</p>
      </div>

      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">¿Qué pasa cuando se siente?</h3>
        <p className="text-gray-700">{emotion.whatHappens}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Actividades de mejora o tranquilidad:</h3>
        <ul className="list-disc list-inside text-blue-700 space-y-3">
          {emotion.improvementActivities.map((activity, index) => {
            if (typeof activity === 'string') {
              return <li key={index}>{activity}</li>;
            } else if (activity.activity && activity.url) {
              return (
                <li key={index}>
                  <a
                    href={activity.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:text-blue-500"
                  >
                    {activity.activity}
                  </a>
                </li>
              );
            } else if (activity.activity && activity.description) {
              return (
                <li key={index}>
                  <strong>{activity.activity}:</strong> {activity.description}
                </li>
              );
            } else {
              return null;
            }
          })}
        </ul>
      </div>
    </div>
  );
};

export default EmotionLegend;
