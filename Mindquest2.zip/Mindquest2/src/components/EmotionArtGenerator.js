import React, { useState } from 'react';

const EmotionArtGenerator = () => {
  const [emotionText, setEmotionText] = useState('');
  const [generatedImage, setGeneratedImage] = useState('');

  const generateArt = async () => {
    // Simulación (cuando tengas la API real, aquí se hace el fetch)
    const imageUrl = `https://source.unsplash.com/600x400/?${encodeURIComponent(emotionText)}`;
    setGeneratedImage(imageUrl);
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4 text-center">Crea arte desde lo que sientes</h2>
      <textarea
        placeholder="Describe cómo te sientes o escribe un pensamiento..."
        value={emotionText}
        onChange={(e) => setEmotionText(e.target.value)}
        className="w-full border p-3 rounded mb-4"
        rows={4}
      />
      <button
        onClick={generateArt}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full"
      >
        Generar imagen emocional
      </button>

      {generatedImage && (
        <div className="mt-6">
          <img src={generatedImage} alt="Arte emocional generado" className="rounded shadow-lg" />
        </div>
      )}
    </div>
  );
};

export default EmotionArtGenerator;
