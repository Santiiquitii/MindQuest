// src/components/MemorySpheres.jsx
import React from "react";
import { motion } from "framer-motion";

const COLORS = {
  alegria: "#fbbf24",
  tristeza: "#60a5fa",
  ira: "#f87171",
  miedo: "#a78bfa",
  amor: "#fb7185",
  sorpresa: "#34d399",
  neutro: "#94a3b8",
};

export default function MemorySpheres({ collectedEmotions = [] }) {
  const [filter, setFilter] = React.useState("all");

  const list = filter === "all"
    ? collectedEmotions
    : collectedEmotions.filter((e) => e === filter || e?.mood === filter || e?.label === filter);

  // conteos para progreso
  const counts = collectedEmotions.reduce((acc, e) => {
    const k = typeof e === "string" ? e : e?.mood || e?.label || "neutro";
    acc[k] = (acc[k] || 0) + 1;
    return acc;
  }, {});
  const total = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
  const ranked = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const EMOS = ["all", ...Object.keys(COLORS)];

  return (
    <section className="panel glass">
      <h3 className="title" style={{ marginBottom: 8 }}>Mis Esferas de Emoción</h3>
      <p className="muted" style={{ marginTop: 0 }}>Aquí aparecerán las emociones que registres.</p>

      {/* Filtros */}
      <div className="filters">
        {EMOS.map((k) => (
          <button
            key={k}
            onClick={() => setFilter(k)}
            className={`pill ${filter === k ? "active" : ""}`}
            style={k !== "all" ? { background: COLORS[k] } : {}}
          >
            {k === "all" ? "Todas" : k[0].toUpperCase() + k.slice(1)}
          </button>
        ))}
      </div>

      {/* Grid de esferas */}
      <div className="sphere-grid">
        {list.length === 0 ? (
          <div className="muted">Aún no hay registros para este filtro.</div>
        ) : (
          list.map((e, i) => {
            const mood = typeof e === "string" ? e : e?.mood || e?.label || "neutro";
            const color = COLORS[mood] || "#94a3b8";
            return (
              <motion.div
                key={i}
                className="sphere-card"
                style={{ background: `radial-gradient( circle at 30% 30%, ${color}, rgba(255,255,255,0.06))` }}
                whileHover={{ rotateX: 6, rotateY: -6, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 200, damping: 18 }}
              >
                <div className="sphere-dot" style={{ background: color }} />
                <div className="sphere-info">
                  <div className="sphere-title">{mood[0].toUpperCase() + mood.slice(1)}</div>
                  <div className="sphere-time">#{i + 1} • {new Date().toLocaleDateString()}</div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Progreso: top emociones */}
      <div className="progress">
        <h4 className="title" style={{ fontSize: 18 }}>Tu mezcla emocional</h4>
        {ranked.length === 0 ? (
          <div className="muted">Registra emociones para ver tu progreso.</div>
        ) : (
          <div className="bars">
            {ranked.map(([mood, count]) => {
              const pct = Math.round((count / total) * 100);
              return (
                <div className="bar-row" key={mood}>
                  <div className="bar-label">{mood[0].toUpperCase() + mood.slice(1)}</div>
                  <div className="bar-track">
                    <div className="bar-fill" style={{ width: `${pct}%`, background: COLORS[mood] }} />
                  </div>
                  <div className="bar-pct">{pct}%</div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
