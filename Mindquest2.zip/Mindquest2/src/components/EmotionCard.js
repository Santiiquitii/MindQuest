import React, { useState } from 'react';

const EmotionCard = ({ emotion, onCollect }) => {
  const [isCollected, setIsCollected] = useState(false);

  const handleCollect = () => {
    setIsCollected(true);
    onCollect(emotion);
  };

  return (
    <div className={`p-4 bg-white rounded-lg shadow-md m-2 ${isCollected ? 'opacity-60' : ''}`}>
      <h3 className="text-xl font-semibold mb-2">{emotion.name}</h3>
      <p className="text-gray-700 text-sm mb-3">{emotion.description}</p>
      {!isCollected ? (
        <button
          onClick={handleCollect}
          className="w-full bg-black text-white py-1 rounded-lg text-sm hover:bg-gray-800 transition-colors"
        >
          Recoger Emoción
        </button>
      ) : (
        <p className="text-center text-green-600 text-sm font-semibold">¡Emoción Recogida!</p>
      )}
    </div>
  );
};

export default EmotionCard;