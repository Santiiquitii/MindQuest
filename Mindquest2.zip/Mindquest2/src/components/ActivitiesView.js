import React, { useState, useRef, useEffect } from 'react';
import ActivityCard from './ActivityCard';
import EmotionLegend from './EmotionLegend';
import { emotionsData } from '../mock/emotions';

/* ========= Actividad rápida: Respiración 4-7-8 ========= */
function QuickBreath478() {
  const [step, setStep] = useState('ready'); // ready | inhale | hold | exhale | done
  const [count, setCount] = useState(0);
  const [round, setRound] = useState(1);
  const timerRef = useRef(null);

  useEffect(() => () => clearInterval(timerRef.current), []);

  const runStep = (name, secs, next) => {
    setStep(name);
    setCount(secs);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCount(c => {
        if (c <= 1) {
          clearInterval(timerRef.current);
          next && next();
          return 0;
        }
        return c - 1;
      });
    }, 1000);
  };

  const start = () => {
    setRound(1);
    const loop = (r = 1) => {
      setRound(r);
      runStep('inhale', 4, () =>
        runStep('hold', 7, () =>
          runStep('exhale', 8, () => {
            if (r < 4) loop(r + 1);
            else setStep('done');
          })
        )
      );
    };
    loop(1);
  };

  const label =
    step === 'inhale' ? 'Inhala por la nariz' :
    step === 'hold'   ? 'Retén el aire' :
    step === 'exhale' ? 'Exhala por la boca' :
    step === 'done'   ? '¡Listo! ¿Cómo te sientes?' :
    'Respiración 4-7-8 (4 rondas)';

  return (
    <div className="text-center">
      <h4 className="font-semibold text-gray-800">Respiración 4-7-8</h4>
      <p className="text-sm text-gray-500 mb-2">Calma ansiedad/estrés en minutos.</p>
      <p className="mb-2">{label}</p>
      {step !== 'ready' && step !== 'done' && (
        <div className="text-4xl my-1">{count}s</div>
      )}
      {step !== 'done' ? (
        <button onClick={start} className="nav-btn">Iniciar</button>
      ) : (
        <button
          onClick={() => { setStep('ready'); setCount(0); setRound(1); }}
          className="nav-btn"
        >
          Repetir
        </button>
      )}
      <p className="mt-2 text-sm text-gray-500">Ronda {round} de 4</p>
    </div>
  );
}

/* ========= Actividad rápida: Anclaje 5-4-3-2-1 ========= */
function QuickGrounding54321() {
  return (
    <div>
      <h4 className="font-semibold text-gray-800">Anclaje 5-4-3-2-1</h4>
      <p className="text-sm text-gray-500 mb-2">Vuelve al presente usando tus sentidos.</p>
      <ol className="list-decimal ml-5 leading-7">
        <li>5 cosas que <b>ves</b></li>
        <li>4 cosas que puedes <b>tocar</b></li>
        <li>3 cosas que <b>oyes</b></li>
        <li>2 cosas que <b>hueles</b></li>
        <li>1 cosa que <b>saboreas</b></li>
      </ol>
      <p className="text-sm text-gray-500 mt-1">Cuando termines, puedes registrarlo en tu Diario.</p>
    </div>
  );
}

/* ========= Bloque contenedor de Actividades Rápidas ========= */
function QuickActivities() {
  return (
    <div className="panel glass p-4 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-3">⚡ Actividades rápidas</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 rounded-lg bg-white/90 shadow">
          <QuickBreath478 />
        </div>
        <div className="p-4 rounded-lg bg-white/90 shadow">
          <QuickGrounding54321 />
        </div>
      </div>
    </div>
  );
}

const ActivitiesView = () => {
  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [selectedActivity, setSelectedActivity] = useState(null);

  const handleSelectEmotion = (emotion) => {
    setSelectedEmotion(emotion);
    setSelectedActivity(null); // reset al cambiar emoción
  };

  const handleSelectActivity = (activity) => {
    setSelectedActivity(activity);
    alert(`¡Iniciando actividad: ${activity}!`);
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">
        Actividades para tus Emociones
      </h2>

      {/* NUEVO: Actividades rápidas siempre visibles arriba */}
      <QuickActivities />

      {!selectedEmotion ? (
        <div>
          <p className="text-center text-gray-700 mb-4">
            Selecciona una emoción para ver actividades relacionadas:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {emotionsData.map(emotion => (
              <div
                key={emotion.id}
                className={`p-4 bg-white rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow border-b-4 border-${emotion.color}-500`}
                onClick={() => handleSelectEmotion(emotion)}
              >
                <h3 className="text-xl font-semibold text-center text-gray-800">
                  {emotion.name}
                </h3>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div>
          <button
            onClick={() => setSelectedEmotion(null)}
            className="mb-4 text-black hover:underline"
          >
            &larr; Volver a Emociones
          </button>

          <EmotionLegend emotion={selectedEmotion} />

          <h3 className="text-2xl font-bold text-center mt-8 mb-4 text-gray-800">
            Actividades para {selectedEmotion.name}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {selectedEmotion.improvementActivities.map((activity, index) => (
              <ActivityCard key={index} activity={activity} onSelect={handleSelectActivity} />
            ))}
          </div>
        </div>
      )}

      {selectedActivity && (
        <div className="mt-6 p-4 bg-green-100 text-green-800 rounded-lg text-center border-l-4 border-green-600">
          Has seleccionado la actividad: "{selectedActivity}". ¡Espero que te ayude!
        </div>
      )}
    </div>
  );
};

export default ActivitiesView;
