// src/assets/emotions/index.js
import alegria from "./Alegria.jpg";
import tristeza from "./Tristeza.jpg";
import ira from "./Furia.jpg";     
import miedo from "./Temor.jpg";   
import ansiedad from "./Ansiedad.jpg"; 



export const EMOTION_AVATARS = {
  alegria,
  tristeza,
  ira,
  miedo,
  ansiedad,
  neutro: alegria, // fallback temporal
};

export function avatarForEmotion(emotion = "neutro") {
  return EMOTION_AVATARS[emotion] || EMOTION_AVATARS.neutro;
}
