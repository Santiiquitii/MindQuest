// src/utils/auth.js
import { deriveKeyFromPassword, passwordVerifier, encryptJson, decryptJson } from "./crypto";

const USERS_INDEX_KEY = "mq:users:index";   // ["ivonne", "alex", ...]
const USER_PREFIX     = "mq:user:";         // mq:user:<username>
const SESSION_KEY     = "mq:session:user";  // username actual

const getJson = (k, def=null) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch { return def; } };
const setJson = (k, v) => localStorage.setItem(k, JSON.stringify(v));

export function listUsers() {
  return getJson(USERS_INDEX_KEY, []);
}
export function getCurrentUser() {
  return localStorage.getItem(SESSION_KEY) || null;
}
export function logout() {
  localStorage.removeItem(SESSION_KEY);
}

export async function createUser(username, password) {
  username = (username||"").trim().toLowerCase();
  if (!username || !password) throw new Error("Usuario y contraseña requeridos");
  const users = new Set(listUsers());
  if (users.has(username)) throw new Error("Ese usuario ya existe");

  const initialVault = {
    profile: { name: "Usuario", birthYear: 2000 },
    diaryEntries: [],
    collectedEmotions: [],
    createdAt: Date.now(),
    version: 1,
  };

  const { key, saltB64 } = await deriveKeyFromPassword(password); // genera salt
  const verifier = await passwordVerifier(password, saltB64);
  const { ivB64, cipherB64 } = await encryptJson(key, initialVault);

  const record = { saltB64, ivB64, cipherB64, verifier };
  setJson(USER_PREFIX + username, record);
  setJson(USERS_INDEX_KEY, [...users, username]);
  localStorage.setItem(SESSION_KEY, username);
  return { username };
}

export async function login(username, password) {
  username = (username||"").trim().toLowerCase();
  const record = getJson(USER_PREFIX + username);
  if (!record) throw new Error("Usuario no encontrado");

  const verify = await passwordVerifier(password, record.saltB64);
  if (verify !== record.verifier) throw new Error("Contraseña incorrecta");

  const { key } = await deriveKeyFromPassword(password, record.saltB64);
  const vault = await decryptJson(key, record.ivB64, record.cipherB64);
  localStorage.setItem(SESSION_KEY, username);
  return { username, key, vault };
}

export async function saveVaultWithKey(username, key, vault) {
  username = (username||"").trim().toLowerCase();
  const recKey = USER_PREFIX + username;
  const record = getJson(recKey);
  if (!record) throw new Error("Usuario no encontrado");

  const { ivB64, cipherB64 } = await encryptJson(key, vault);
  setJson(recKey, { ...record, ivB64, cipherB64 });
}

export async function changePassword(username, oldPassword, newPassword) {
  username = (username||"").trim().toLowerCase();
  const recKey = USER_PREFIX + username;
  const record = getJson(recKey);
  if (!record) throw new Error("Usuario no encontrado");

  const verify = await passwordVerifier(oldPassword, record.saltB64);
  if (verify !== record.verifier) throw new Error("Contraseña actual incorrecta");

  const { key: oldKey } = await deriveKeyFromPassword(oldPassword, record.saltB64);
  const vault = await decryptJson(oldKey, record.ivB64, record.cipherB64);

  const { key: newKey, saltB64: newSalt } = await deriveKeyFromPassword(newPassword);
  const newVerifier = await passwordVerifier(newPassword, newSalt);
  const { ivB64, cipherB64 } = await encryptJson(newKey, vault);

  setJson(recKey, { saltB64: newSalt, ivB64, cipherB64, verifier: newVerifier });
}
