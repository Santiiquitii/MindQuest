// src/utils/chatApi.js
const BASE = process.env.REACT_APP_CHATBOT_URL || "http://localhost:5000";

export async function sendToBot(mensaje, sessionId) {
  const r = await fetch(`${BASE}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mensaje, sessionId }),
  });

  if (!r.ok) throw new Error("Bad response");
  return await r.json();
}