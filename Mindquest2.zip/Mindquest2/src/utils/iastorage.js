const IA_STORAGE_KEY = 'mindquest:ia-detections';

export function getIADetections() {
  try {
    const raw = localStorage.getItem(IA_STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveIADetections(data) {
  localStorage.setItem(IA_STORAGE_KEY, JSON.stringify(data));
}

export function resetIADetections() {
  localStorage.removeItem(IA_STORAGE_KEY);
}
