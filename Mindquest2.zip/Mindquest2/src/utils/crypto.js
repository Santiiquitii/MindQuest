// src/utils/crypto.js

const te = new TextEncoder();
const td = new TextDecoder();

const toB64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const fromB64 = (b64) => Uint8Array.from(atob(b64), c => c.charCodeAt(0)).buffer;

export function bufToB64(buf) { return toB64(buf); }
export function b64ToBuf(b64) { return fromB64(b64); }

export async function deriveKeyFromPassword(password, saltB64, iterations = 250_000) {
  const salt = saltB64 ? fromB64(saltB64) : crypto.getRandomValues(new Uint8Array(16)).buffer;
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    te.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"] // ✅ clave solo para deriveKey (AES-GCM)
  );
  const key = await crypto.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,                  // ⛔ no-extractable
    ["encrypt", "decrypt"]
  );
  return { key, saltB64: toB64(salt) };
}

// ✅ Nueva implementación: deriva bits con PBKDF2 y hashealos
export async function passwordVerifier(password, saltB64, iterations = 250_000) {
  const salt = saltB64 ? fromB64(saltB64) : crypto.getRandomValues(new Uint8Array(16)).buffer;

  // Importa material solo para deriveBits
  const material = await crypto.subtle.importKey(
    "raw",
    te.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"]
  );

  // Deriva 256 bits determinísticos para esta password+salt
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    material,
    256
  );

  // (Opcional) Hashea esos bits para compactar/normalizar
  const hash = await crypto.subtle.digest("SHA-256", bits);
  return toB64(hash); // este string es tu "verifier" estable
}

export async function encryptJson(key, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plaintext = te.encode(JSON.stringify(obj));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);
  return { ivB64: toB64(iv.buffer), cipherB64: toB64(cipher) };
}

export async function decryptJson(key, ivB64, cipherB64) {
  const iv = new Uint8Array(fromB64(ivB64));
  const cipher = fromB64(cipherB64);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipher);
  return JSON.parse(td.decode(plain));
}
