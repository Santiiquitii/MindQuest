export const getRecommendedActivity = (emotion) => {
  const activities = emotion.improvementActivities;
  if (!activities || activities.length === 0) return null;

  const randomIndex = Math.floor(Math.random() * activities.length);
  return activities[randomIndex];
};
