// src/utils/iaCoach.js

// ===============================
// LÉXICO DE EMOCIONES (ES/emoji)
// ===============================
export const EMOTIONS = ["alegria", "tristeza", "ira", "miedo", "ansiedad", "neutro"];

export const EMO_LEXICON = {
  alegria: [/(\b|_)alegr[ií]a(\b|_)|feliz|content[ao]\b|(?:\b|_)bien(\b|_)|animad[ao]\b|😊|😀|😁/i],
  tristeza: [/triste(za)?\b|deprimid[ao]\b|baj[ao]\b|(?:\b|_)mal(\b|_)|😔|😢|😭/i],
  ira: [/(\b|_)ira(\b|_)|enojad[ao]\b|molest[ao]\b|rabia\b|furia\b|furios[ao]\b|😡|🤬/i],
  miedo: [/miedo\b|tem[eo]r\b|😨|😰|😱/i],
  ansiedad: [/ansieda[d]?\b|ansios[ao]\b|nervios[oa]?\b|estr[eé]s\b|estresad[ao]\b|😰|😵‍💫|🫨/i],
  neutro: [/neutr[oa]\b|normal\b|meh\b|tranquil[ao]\b|ok\b|😶/i],
};

// ================
// Utilidades base
// ================
const normalizeStr = (s = "") =>
  (s || "")
    .toString()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, ""); // quitar tildes

export const isKnownEmotion = (k) => EMOTIONS.includes((k || "").toLowerCase());

// =========================================
// PATRONES SENCILLOS PARA EXTRAER ACCIONES
// =========================================
const ACTION_PATTERNS = [
  /(ir a|salir a)\s+([a-záéíóúñü]+(?:\s+[a-záéíóúñü]+){0,3})/i,
  /(ver|mirar)\s+(una? |la |el )?([a-záéíóúñü]+(?:\s+[a-záéíóúñü]+){0,3})/i,
  /(escuchar|o[ií]r)\s+(m[uú]sica|podcast|canci[oó]n(?:es)?)/i,
  /(hablar|llamar|chatear)\s+(con\s+)?([a-záéíóúñü]+)/i,
  /(hacer|practicar|jugar)\s+(deporte|f[uú]tbol|b[aá]squet|videojuegos|yoga|meditaci[oó]n)/i,
  /(salir|caminar|correr|pasear)(?:\s+por\s+([a-záéíóúñü]+))?/i,
  /(comer|preparar|cocinar)\s+(algo|[a-záéíóúñü]+(?:\s+[a-záéíóúñü]+){0,2})/i,
  /(leer|estudiar)\s+([a-záéíóúñü]+(?:\s+[a-záéíóúñü]+){0,2})/i,
  /(ver a|reunirme? con)\s+([a-záéíóúñü]+)/i,
];

// =====================
// DETECCIÓN DE EMOCIÓN
// =====================
export function detectEmotion(entry) {
  // 1) Si ya viene etiquetado
  if (typeof entry === "object" && entry) {
    const k = entry.emotion || entry.mood || entry.label;
    if (k && typeof k === "string") {
      const low = k.toLowerCase();
      return isKnownEmotion(low) ? low : "neutro";
    }
  }
  // 2) Detectar por texto
  const raw = (typeof entry === "string" ? entry : entry?.text || "") || "";
  const text = normalizeStr(raw);
  for (const [emo, regs] of Object.entries(EMO_LEXICON)) {
    if (regs.some((re) => re.test(text))) return emo;
  }
  return "neutro";
}

// ====================
// EXTRACCIÓN ACCIONES
// ====================
export function extractAction(text = "") {
  const raw = text || "";
  for (const re of ACTION_PATTERNS) {
    const m = raw.match(re);
    if (m) {
      const verb = (m[1] || m[0]).trim().toLowerCase();
      const obj = (m[3] || m[2] || "").toLowerCase().trim();
      let pretty = verb;
      if (obj) pretty += " " + obj;
      return pretty.replace(/\s+por\s+$/, "").replace(/\s{2,}/g, " ").trim();
    }
  }
  return null;
}

// ======================
// NORMALIZAR ENTRADAS
// ======================
export function normalizeDiaryItem(item) {
  const text = typeof item === "string" ? item : item?.text || "";
  const emotion = detectEmotion(item);
  const action = extractAction(text);

  let ts = null;
  if (item && typeof item === "object") {
    ts = item.ts || item.time || item.timestamp || item.date || item.createdAt || null;
  }
  if (typeof ts === "string") {
    const d = new Date(ts);
    ts = isNaN(d.getTime()) ? null : d.getTime();
  }
  return { emotion, action, ts, text };
}

// =========================================
// AGRUPAR EN { emoción: { total, actions } }
// =========================================
export function buildInsights(entries = []) {
  const insights = {};
  for (const raw of entries) {
    const n = normalizeDiaryItem(raw);
    if (!insights[n.emotion]) insights[n.emotion] = { total: 0, actions: {} };
    insights[n.emotion].total += 1;
    if (n.action) {
      insights[n.emotion].actions[n.action] =
        (insights[n.emotion].actions[n.action] || 0) + 1;
    }
  }
  return insights;
}

// ===================================
// PARSEO SIMPLE DE VENTANA TEMPORAL
// ===================================
function parseTimeWindow(q = "") {
  const s = normalizeStr(q.toLowerCase());
  const now = new Date();

  const startOfDay = (d) =>
    new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const endOfDay = (d) => startOfDay(d) + 24 * 60 * 60 * 1000 - 1;

  if (/\bhoy\b/.test(s)) {
    return { from: startOfDay(now), to: Date.now(), label: "hoy" };
  }
  if (/ayer/.test(s)) {
    const y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    return { from: startOfDay(y), to: endOfDay(y), label: "ayer" };
  }
  if (/(esta semana|ultimos? 7 dias)/.test(s)) {
    return {
      from: Date.now() - 7 * 24 * 60 * 60 * 1000,
      to: Date.now(),
      label: "últimos 7 días",
    };
  }
  if (/(semana pasada)/.test(s)) {
    const day = now.getDay() || 7; // 1..7
    const lastMonday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - day - 6
    );
    const lastSunday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - day
    );
    return { from: startOfDay(lastMonday), to: endOfDay(lastSunday), label: "semana pasada" };
  }
  if (/(este mes)/.test(s)) {
    const from = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    return { from, to: Date.now(), label: "este mes" };
  }
  if (/(ultimo mes|ultimos? 30 dias)/.test(s)) {
    return {
      from: Date.now() - 30 * 24 * 60 * 60 * 1000,
      to: Date.now(),
      label: "últimos 30 días",
    };
  }
  return null;
}

function filterByWindow(normalizedEntries, win) {
  if (!win)
    return {
      list: normalizedEntries,
      anyTs: normalizedEntries.some((e) => typeof e.ts === "number"),
      windowApplied: false,
    };
  const anyTs = normalizedEntries.some((e) => typeof e.ts === "number");
  if (!anyTs) {
    return { list: normalizedEntries, anyTs, windowApplied: false };
  }
  const list = normalizedEntries.filter(
    (e) => typeof e.ts === "number" && e.ts >= win.from && e.ts <= win.to
  );
  return { list, anyTs, windowApplied: true, label: win.label };
}

// ==========================================
// ELEGIR EMOCIÓN (pregunta o más frecuente)
// ==========================================
export function pickEmotionFromQuestion(q = "", insights, fallback = "neutro") {
  const lower = q.toLowerCase();
  for (const emo of Object.keys(EMO_LEXICON)) {
    const regs = EMO_LEXICON[emo];
    if (regs.some((re) => re.test(lower))) return emo;
  }
  let best = fallback;
  let bestCount = -1;
  for (const [emo, data] of Object.entries(insights || {})) {
    if (data.total > bestCount) {
      best = emo;
      bestCount = data.total;
    }
  }
  return best;
}

// ==================================
// RESPUESTA PRINCIPAL DEL COACH IA
// ==================================
export function answerQuestion(question, diaryEntries = []) {
  const normalized = (diaryEntries || []).map(normalizeDiaryItem);
  const win = parseTimeWindow(question);
  const { list, anyTs, windowApplied, label } = filterByWindow(normalized, win);

  const insights = buildInsights(list);
  const emotion = pickEmotionFromQuestion(question, insights, "neutro");
  const data = insights[emotion];

  if (!data || data.total === 0) {
    const scope = windowApplied ? ` ${label}` : anyTs ? " recientemente" : "";
    return {
      emotion,
      text:
        `Aún no encuentro suficientes registros${scope} en tu diario para detectar patrones. ` +
        `Prueba escribiendo algunas entradas más 🙂`,
    };
  }

  const top = Object.entries(data.actions)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  if (top.length === 0) {
    const suffix = windowApplied ? ` ${label}` : "";
    return {
      emotion,
      text:
        `Cuando sientes **${pretty(emotion)}**${suffix}, todavía no hay acciones repetidas en tu diario. ` +
        `Anota qué haces y pronto verás patrones.`,
    };
  }

  const bullets = top
    .map(([action, count]) => `• Sueles **${action}** (${count}×)`)
    .join("\n");
  const suffix = windowApplied ? ` (${label})` : "";
  const summary = `Cuando sientes **${pretty(emotion)}**${suffix}:\n${bullets}\n\n¿Quieres que te sugiera una actividad para ese estado?`;
  return { emotion, text: summary };
}

// ==================================
// SUGERENCIAS DE ACTIVIDAD POR EMOCIÓN
// ==================================
export function recommendActivityForEmotion(emotion = "neutro") {
  const recs = {
    alegria: {
      id: "gratitud-rapida",
      title: "Gratitud rápida",
      description: "Escribe 3 cosas por las que te sientas agradecida/o hoy.",
      tag: "reflexión",
    },
    tristeza: {
      id: "respiracion-4-7-8",
      title: "Respiración 4-7-8",
      description: "Inhala 4s, retén 7s, exhala 8s. 6 repeticiones.",
      tag: "respiración",
    },
    ira: {
      id: "descarga-fisica-suave",
      title: "Descarga física suave",
      description: "Camina 10 minutos o haz estiramientos de cuello y hombros.",
      tag: "movimiento",
    },
    miedo: {
      id: "anclaje-5-4-3-2-1",
      title: "Anclaje sensorial 5-4-3-2-1",
      description:
        "Nombra 5 cosas que ves, 4 que sientes, 3 que oyes, 2 que hueles, 1 que saboreas.",
      tag: "grounding",
    },
    ansiedad: {
      id: "respiracion-coherente",
      title: "Respiración coherente 5-5",
      description:
        "Inhala 5s y exhala 5s durante 3–5 minutos para calmar el sistema nervioso.",
      tag: "respiración",
    },
    neutro: {
      id: "escaneo-corporal",
      title: "Escaneo corporal",
      description:
        "Recorre tu cuerpo de pies a cabeza y detecta tensiones por 2-3 min.",
      tag: "atención plena",
    },
  };
  return recs[emotion] || recs.neutro;
}

// ==============
// FORMATEADORES
// ==============
function pretty(k) {
  const map = {
    alegria: "Alegría",
    tristeza: "Tristeza",
    ira: "Furia",
    miedo: "Temor",
    ansiedad: "Ansiedad",
    neutro: "Neutro",
  };
  return map[k] || k;
}
