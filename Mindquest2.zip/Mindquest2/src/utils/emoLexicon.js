// src/utils/emoLexicon.js

// Diccionario de emociones con sinónimos/emoji para detectar en español
export const EMO_LEXICON = {
  alegria: [/alegr[ií]a|feliz|content[ao]|bien|animad[ao]|😊|😀|😁/i],
  tristeza: [/triste(za)?|deprimid[ao]|baj[ao]|mal|😔|😢|😭/i],
  ira: [/ira|enojad[ao]|molest[ao]|rabia|furia|furios[ao]|😡|🤬/i],
  miedo: [/miedo|tem[eo]r|😨|😰|😱/i],
  ansiedad: [/ansieda[d]?|ansios[ao]|nervios[oa]?|estr[eé]s|estresad[ao]|😰|😵‍💫|🫨/i],
  neutro: [/neutr[oa]|normal|meh|tranquil[ao]|ok|😶/i],
};
// Re-exporta funciones para no romper imports antiguos:
export { detectEmotion, normalizeDiaryItem } from "./iaCoach";
