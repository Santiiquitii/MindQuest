export const emotionsData = [
  {
    id: 1,
    name: "Alegría",
    color: "yellow",
    description: "La alegría es una emoción positiva que se experimenta ante situaciones placenteras o satisfactorias. Se manifiesta con una sensación de bienestar, optimismo y energía.",
    howItHappens: "Se da ante logros, buenas noticias, momentos de conexión social, o simplemente al disfrutar de actividades que nos gustan.",
    whatHappens: "Cuando se siente alegría, el cuerpo libera endorfinas, lo que reduce el estrés y mejora el estado de ánimo. Aumenta la motivación y la creatividad.",
    improvementActivities: [
      {
      activity:"Bailar tu canción favorita.",
      url:'https://open.spotify.com/playlist/3w1sdydLKcXkA0tL5DM1ho?si=e33ff668867447ed&pt=628249ed438eaf2d3aff07c65fdf3fdf'
      },
      {
      activity:"Ver un video divertido.",
      url:'https://youtu.be/Vfw7PONFBTw?si=KanS8E46eNdU7cea'
      },
      {
      activity:"Compartir un chiste con alguien.",
      description: 'Saca tu lado divertido, inspirate en sacar tu bromista interior'
      },
      {
      activity:"Recordar un momento feliz.",
      description:' Adentrate en tus pensamientos y recuerda aquello que te hizo feliz. Recuerda que RECORDAR ES VIVIR'
      }
    
    ]
  },
  {
    id: 2,
    name: "Tristeza",
    color: "blue",
    description: "La tristeza es una emoción que surge ante pérdidas, decepciones o situaciones dolorosas. Se caracteriza por una sensación de melancolía, desánimo y falta de energía.",
    howItHappens: "Se da ante la pérdida de un ser querido, una ruptura, un fracaso, o al enfrentar situaciones difíciles.",
    whatHappens: "Cuando se siente tristeza, el cuerpo puede experimentar fatiga y falta de apetito. Es una emoción que invita a la introspección y a buscar consuelo.",
    improvementActivities: [
      {
      activity:"Escuchar música tranquila que te ayude a pensar mejor.",
      url:'https://youtu.be/263Vb6xiifo?si=QqsXK6mRov2ezPbv'
      },
      {
      activity:"Abrazar una almohada o mascota.",
      description:'Abrazar a una mascota a una almohada aliviara aquel sentimiento que invade tu personalidad'
      },
      {
      activity:"Ver una película triste (para llorar un poquito).",
      description:'A veces solo sirve estar solo y ayudarte con una pelicula, añadir algo de melancolia no estara mal.'
      },
      {
     activity:"Escribir sobre lo que sientes.",
     description:'Entra anuestro diario, es tu espacio y expresate libremente'
      }
      
 
    ]
  },
  {
    id: 3,
    name: "Enojo",
    color: "red",
    description: "El enojo es una emoción que aparece ante situaciones que percibimos como injustas, amenazantes o frustrantes. Se manifiesta con irritabilidad, tensión y ganas de defenderse.",
    howItHappens: "Se da ante conflictos, críticas, obstáculos para lograr objetivos, o al sentir que nuestros límites son invadidos.",
    whatHappens: "Cuando se siente enojo, el cuerpo libera adrenalina, lo que aumenta la frecuencia cardíaca y la tensión muscular. Puede llevar a reacciones impulsivas.",
    improvementActivities: [
      {
      activity:"Apretar una pelota antiestrés.",
      description:'Desata tu furia apretando una pelota antiestres, esto ayudara a regular tus niveles altos de frecuencia cardiaca'
      },
      {
     activity:"Dar golpes suaves a una almohada.",
     description:'Toma una almohada y pegale puños, esto ayudara a regular tu emocion'
      },
      {
      activity:"Dibujar o pintar con colores fuertes.",
      description:' Dibujoar es una actividad efectiva para estos casos, ya que distraera tu mente'
      },
      {
      activity:"Gritar en un lugar donde nadie te escuche.",
      description:'Grita lo mas fuerte que puedas esto ayudara a soltar todo aquello que te enoja'
      }

    ]
  },
  {
    id: 4,
    name: "Miedo",
    color: "purple",
    description: "El miedo es una emoción que surge ante una amenaza real o percibida. Se caracteriza por una sensación de peligro, ansiedad y ganas de huir o paralizarse.",
    howItHappens: "Se da ante situaciones desconocidas, peligros físicos, o al anticipar resultados negativos.",
    whatHappens: "Cuando se siente miedo, el cuerpo se prepara para la acción (lucha o huida). Aumenta la frecuencia cardíaca y la respiración.",
    improvementActivities: [
      {
     activity:"Respirar hondo varias veces.",
     url:'https://youtu.be/EGO5m_DBzF8?si=hbXJ1FrBt4EMCRSN'
      },
      {
      activity:"Imaginar un lugar seguro.",
      description:'Piensa en todo aquello que te hace sentir segur@, esto te ayudara a calamar tu sistema nervioso'
      },
      {
     activity:"Hablar con alguien que te haga sentir seguro.",
     description:'Para estos casos una mano amiga no te hará daño. Busca a tu persona de confianza'
      },
      {
      activity:"Escribir tus miedos en un papel y romperlo.",
      description:'Toma una hoja de papel y escribe todo ello que te afecta, rompelo y veras como te aliviaras. Esto ayuda a soltar por completo aquello que te afecta'
      }
    ]
  },
  {
    id: 5,
    name: "Ansiedad",
    color: "orange",
    description:  'Sensación de preocupación o miedo intenso. Es normal sentir ansiedad ante situaciones desconocidas.',
    howItHappens: 'Aparece cuando anticipamos cosas que aún no han pasado.',
    whatHappens: 'Podemos sentir palpitaciones, tensión o dificultad para concentrarnos.',
    improvementActivities: [
      {
       activity:'Realizar ejercicios de respiración profunda',
       url:'https://youtu.be/EGO5m_DBzF8?si=hbXJ1FrBt4EMCRSN'
      },
      {
      activity:'Hablar con un amigo o familiar',
      description:'Contacta a un Familiar o un amigo con quien te sientas segur@ para calmar este ataque'
      },
      {
      activity:'Hacer una caminata al aire libre',
      description:'Liberate de todo tipo de tension, deja de lado a aquello que te preocupa, disfruta de la naturaleza con una caminata al aire libre mientras escuchas tu musica favorita'
      },
      {
      activity:'Escribir lo que estás sintiendo en un diario',
      description:'Entra a nuestra herramienta de diario y expresate libremente. Este es tu espacio'
      }
    ]
  }
];