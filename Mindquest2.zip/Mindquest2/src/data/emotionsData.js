// src/data/emotionsData.js
const mk = (name, description, howItHappens, whatHappens, improvementActivities) => ({
  name, description, howItHappens, whatHappens, improvementActivities,
});

// Solo emociones soportadas por tu app/avatares
export const EMOTIONS_DATA = [
  mk(
    "alegría",
    "Estado de bienestar, ligereza y energía positiva.",
    "Aparece cuando percibes logros, vínculos, disfrute o gratitud.",
    "Aumenta la motivación, la creatividad y la conexión social.",
    [
      "Escribe 3 cosas por las que te sientas agradecida/o.",
      { activity: "Compartir buena noticia", description: "Cuéntale a alguien lo positivo de tu día." },
      { activity: "Playlist energética", url: "https://open.spotify.com/" },
    ]
  ),
  mk(
    "tristeza",
    "Sensación de pérdida, vacío o desánimo.",
    "Se da ante pérdidas, frustraciones o cansancio prolongado.",
    "Disminuye energía y enfoque, invita a la introspección.",
    [
      "Respiración 4-7-8 por 2–3 min.",
      { activity: "Escribir una carta", description: "Explora qué perdiste y qué necesitas." },
      { activity: "Caminar suave", url: "https://www.youtube.com/results?search_query=walk+10+min" },
    ]
  ),
  mk(
    "ira",
    "Activación intensa ante injusticias o límites vulnerados.",
    "Surge cuando percibes que algo importante fue traspasado.",
    "Aumenta tensión corporal y pensamientos rápidos.",
    [
      "Descarga física suave: estiramientos cuello/hombros.",
      { activity: "Límites claros", description: "Escribe 1 límite y cómo comunicarlo." },
      { activity: "Cuenta regresiva", url: "https://www.youtube.com/results?search_query=breathing+countdown" },
    ]
  ),
  mk(
    "miedo",
    "Respuesta de alerta ante amenaza real o anticipada.",
    "Se activa con incertidumbre o peligro (real o percibido).",
    "Aumenta vigilancia, acelera la respiración.",
    [
      "Anclaje 5-4-3-2-1 (sentidos).",
      { activity: "Mapa de control", description: "Lista lo que sí puedes controlar hoy." },
      { activity: "Box breathing 4-4-4-4", url: "https://www.youtube.com/results?search_query=box+breathing" },
    ]
  ),
  mk(
    "ansiedad",
    "Preocupación anticipatoria con inquietud y tensión.",
    "Aparece ante sobrecarga, incertidumbre o exceso de estímulos.",
    "Genera rumiación, tensión muscular y respiración superficial.",
    [
      "Respiración coherente 5-5 por 3–5 min.",
      { activity: "Descarga mental", description: "Haz un listado rápido de pendientes y prioriza 1." },
      { activity: "Relajación guiada", url: "https://www.youtube.com/results?search_query=body+scan+10+minutes" },
    ]
  ),
];
