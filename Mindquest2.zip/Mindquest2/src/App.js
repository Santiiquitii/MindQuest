// src/App.jsx
import React, { useState, useEffect, useMemo } from 'react';
import AvatarSelector from './components/AvatarSelector';
import DiaryView from './components/DiaryView';
import HelplineView from './components/HelplineView';
import UserInfoModal from './components/UserInfoModal';
import EmotionInput from './components/EmotionInput';
import MemorySpheres from './components/MemorySpheres';
import LandingPage from './components/LandingPage';
import UserProfile from './components/UserProfile';
import MiniGamesView from './components/MiniGamesView';
import EmotionalProgressView from './components/EmotionalProgressView';
import ReconocimientoIA from './components/ReconocimientoIA';
import ResumenIA from './components/ResumenIA';
import ActivitiesView from './components/ActivitiesView';
import SidebarMenu from './components/SidebarMenu';
import { EMOTIONS_DATA } from './data/emotionsData';
import { normalizeDiaryItem, detectEmotion } from './utils/iaCoach';

// 💬 Botón flotante de chat (Sísifo)
import FloatingChat from './components/FloatingChat';

// 🔐 Auth
import AuthGate from './components/AuthGate';
import { saveVaultWithKey, logout } from './utils/auth';

import './styles.css';

// Tema por emoción
const EMOTION_THEME = {
  alegria: 'theme-alegria',
  tristeza: 'theme-tristeza',
  ira: 'theme-ira',
  miedo: 'theme-miedo',
  ansiedad: 'theme-ansiedad',
  neutro: 'theme-neutro',
};

const App = () => {
  const [auth, setAuth] = useState(null);

  const [currentPage, setCurrentPage] = useState('landing');
  const [userProfile, setUserProfile] = useState(null);
  const [collectedEmotions, setCollectedEmotions] = useState([]);
  const [showUserInfoModal, setShowUserInfoModal] = useState(false);
  const [diaryEntries, setDiaryEntries] = useState([]);
  const [vaultMeta, setVaultMeta] = useState({ createdAt: null, version: 1 });

  useEffect(() => {
    if (!auth) return;
    const v = auth.vault || {};
    setUserProfile(v.profile || { name: 'Usuario', birthYear: 2000 });
    setDiaryEntries(Array.isArray(v.diaryEntries) ? v.diaryEntries : []);
    setCollectedEmotions(Array.isArray(v.collectedEmotions) ? v.collectedEmotions : []);
    setVaultMeta({ createdAt: v.createdAt || Date.now(), version: v.version || 1 });
    setCurrentPage('game');
  }, [auth]);

  useEffect(() => {
    if (!auth) return;

    const newVault = {
      profile: userProfile || { name: 'Usuario', birthYear: 2000 },
      diaryEntries,
      collectedEmotions,
      createdAt: vaultMeta.createdAt || Date.now(),
      version: vaultMeta.version || 1,
    };

    saveVaultWithKey(auth.username, auth.key, newVault).catch((e) =>
      console.error('Error guardando bóveda:', e)
    );
  }, [auth, userProfile, diaryEntries, collectedEmotions, vaultMeta]);

  const handleProfileCreated = (profileData) => {
    setUserProfile(profileData || { name: 'Usuario', birthYear: 2000 });
    setCollectedEmotions([]);
    setDiaryEntries([]);
    setCurrentPage('game');
  };

  const handleEmotionInputSelected = (emotion) => {
    const emo = (
      typeof emotion === 'string'
        ? emotion
        : emotion?.emotion || emotion?.mood || 'neutro'
    ).toLowerCase();

    setCollectedEmotions((prev) => [...prev, emo]);
  };

  const handleAddDiaryEntry = (itemOrText) => {
    const item =
      typeof itemOrText === 'string'
        ? normalizeDiaryItem({
            text: itemOrText,
            ts: Date.now(),
            emotion: detectEmotion(itemOrText),
          })
        : itemOrText;

    setDiaryEntries((prev) => [item, ...prev]);

    const emo = (item.emotion || 'neutro').toLowerCase();
    setCollectedEmotions((prev) => [...prev, emo]);
  };

  const handleDeleteDiaryEntry = (idx) => {
    setDiaryEntries((prev) => prev.filter((_, i) => i !== idx));
  };

  const lastEmotion = useMemo(() => {
    if (!collectedEmotions?.length) return 'neutro';
    const last = collectedEmotions[collectedEmotions.length - 1];
    if (typeof last === 'string') return last.toLowerCase();
    return (last?.emotion || last?.mood || last?.label || 'neutro').toLowerCase();
  }, [collectedEmotions]);

  const activeTheme = EMOTION_THEME[lastEmotion] || 'theme-neutro';

  useEffect(() => {
    window.mqNavigate = (route) => {
      const map = {
        '/': 'landing',
        '/game': 'game',
        '/diario': 'diary',
        '/activities': 'activities',
        '/minijuegos': 'minigames',
        '/progreso': 'progress',
        '/ia': 'ia',
        '/reconocimiento': 'ia',
        '/ayuda': 'helplines',
        '/perfil': 'profile',
      };

      const target = map[route];
      if (target) setCurrentPage(target);
    };

    return () => {
      delete window.mqNavigate;
    };
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onStart={() => setCurrentPage('avatar')} />;

      case 'avatar':
        return <AvatarSelector onProfileCreated={handleProfileCreated} />;

      case 'game':
        return (
          <>
            <div className="panel glass">
              <EmotionInput onEmotionSelected={handleEmotionInputSelected} />
            </div>

            <MemorySpheres
              collectedEmotions={collectedEmotions}
              onClear={() => setCollectedEmotions([])}
            />
          </>
        );

      case 'diary':
        return (
          <div className="panel glass">
            <DiaryView
              diaryEntries={diaryEntries}
              onAddEntry={handleAddDiaryEntry}
              onDeleteEntry={handleDeleteDiaryEntry}
            />
          </div>
        );

      case 'activities':
        return (
          <div className="panel glass">
            <ActivitiesView emotionsData={EMOTIONS_DATA} />
          </div>
        );

      case 'helplines':
        return (
          <div className="panel glass">
            <HelplineView />
          </div>
        );

      case 'profile':
        return (
          <div className="panel glass">
            <UserProfile lastEmotion={lastEmotion} />
          </div>
        );

      case 'minigames':
        return (
          <div className="panel glass">
            <MiniGamesView />
          </div>
        );

      case 'progress':
        return (
          <div className="panel glass">
            <EmotionalProgressView
              diaryEntries={diaryEntries}
              collectedEmotions={collectedEmotions}
              onReset={() => {
                setDiaryEntries([]);
                setCollectedEmotions([]);
              }}
            />
          </div>
        );

      case 'ia':
        return (
          <div className="panel glass">
            <ReconocimientoIA goToResumen={() => setCurrentPage('iaSummary')} />
          </div>
        );

      case 'iaSummary':
        return (
          <div className="panel glass">
            <ResumenIA goBack={() => setCurrentPage('ia')} />
          </div>
        );

      default:
        return <LandingPage onStart={() => setCurrentPage('avatar')} />;
    }
  };

  if (!auth) {
    return <AuthGate onAuthenticated={setAuth} />;
  }

  return (
    <div className={`app-bg ${activeTheme}`}>
      {currentPage !== 'landing' && (
        <SidebarMenu
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          onLogout={() => {
            logout();
            setAuth(null);
          }}
        />
      )}

      <main className="content">
        {renderPage()}
      </main>

      {showUserInfoModal && (
        <UserInfoModal onClose={() => setShowUserInfoModal(false)} />
      )}

      <FloatingChat />
    </div>
  );
};

export default App;