import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tuempresa.mindquest',
  appName: 'MindQuest',
  webDir: 'build'
};

export default config;
